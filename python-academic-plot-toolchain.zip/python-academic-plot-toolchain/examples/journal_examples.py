"""
学术图表工具链使用示例

演示如何使用面向学术出版的Python图表工具链，
生成符合《计算机工程与应用》、IEEE、Nature/Science等期刊规范的图表。
"""

import numpy as np
import matplotlib.pyplot as plt
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.plot_utils import (
    setup_publication_style,
    get_figure_size,
    save_multiformat,
    check_compliance,
    list_supported_publications,
    get_publication_info
)


def example_1_basic_usage():
    """示例1: 基本使用 - 生成符合期刊规范的简单图表"""
    print("=" * 60)
    print("示例1: 基本使用 - 计算机工程与应用期刊样式")
    print("=" * 60)
    
    # 使用出版物样式上下文管理器
    with setup_publication_style('cea'):
        # 获取期刊推荐的单栏尺寸
        figsize = get_figure_size('cea', 'single')
        print(f"使用图形尺寸: {figsize} inches")
        
        # 创建图表
        fig, ax = plt.subplots(figsize=figsize, dpi=300)
        
        # 生成示例数据
        x = np.linspace(0, 10, 100)
        y1 = np.sin(x)
        y2 = np.cos(x)
        
        # 绘制曲线
        ax.plot(x, y1, label='正弦曲线', linewidth=1.0)
        ax.plot(x, y2, label='余弦曲线', linewidth=1.0, linestyle='--')
        
        # 设置标签（使用期刊规范字体和字号）
        ax.set_xlabel('时间 (s)')
        ax.set_ylabel('振幅')
        ax.set_title('正弦和余弦函数')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # 合规性检查
        from utils.plot_utils.configs.publication_config import CEA_CONFIG
        report = check_compliance(fig, CEA_CONFIG)
        print("\n合规性检查:")
        print(report)
        
        # 保存多格式
        output_dir = "output/example1"
        import os
        os.makedirs(output_dir, exist_ok=True)
        paths = save_multiformat(
            fig, 
            f"{output_dir}/cea_example",
            formats=['png', 'svg', 'pdf', 'eps'],
            dpi=300
        )
        print(f"\n已保存文件:")
        for path in paths:
            print(f"  - {path}")
        
        plt.close(fig)
    
    print("\n")


def example_2_ieee_style():
    """示例2: IEEE Transactions期刊样式"""
    print("=" * 60)
    print("示例2: IEEE Transactions期刊样式")
    print("=" * 60)
    
    with setup_publication_style('ieee'):
        # IEEE双栏图表尺寸
        figsize = get_figure_size('ieee', 'double')
        print(f"使用图形尺寸: {figsize} inches")
        
        fig, ax = plt.subplots(figsize=figsize, dpi=300)
        
        # 生成性能对比数据
        methods = ['Method A', 'Method B', 'Method C', 'Method D']
        accuracy = [0.85, 0.88, 0.92, 0.95]
        
        # 绘制柱状图
        bars = ax.bar(methods, accuracy, color='#0066CC', alpha=0.8)
        
        # 添加数值标签
        for bar, acc in zip(bars, accuracy):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{acc:.2f}',
                   ha='center', va='bottom', fontsize=7)
        
        ax.set_xlabel('方法')
        ax.set_ylabel('准确率')
        ax.set_title('不同方法的性能对比')
        ax.set_ylim(0.8, 1.0)
        ax.grid(True, axis='y', alpha=0.3, linestyle=':')
        
        # 保存
        output_dir = "output/example2"
        import os
        os.makedirs(output_dir, exist_ok=True)
        paths = save_multiformat(
            fig,
            f"{output_dir}/ieee_example",
            formats=['png', 'svg', 'pdf', 'eps'],
            dpi=300
        )
        print(f"已保存文件:")
        for path in paths:
            print(f"  - {path}")
        
        plt.close(fig)
    
    print("\n")


def example_3_multi_subplot():
    """示例3: 多子图组合 - 复杂图表"""
    print("=" * 60)
    print("示例3: 多子图组合 - 复杂图表")
    print("=" * 60)
    
    with setup_publication_style('nature'):
        # Nature单栏尺寸
        figsize = get_figure_size('nature', 'single')
        # 调整高度以容纳2x2子图
        figsize = (figsize[0], figsize[0] * 1.2)
        
        fig, axes = plt.subplots(2, 2, figsize=figsize, dpi=300)
        fig.patch.set_facecolor('white')
        
        # 生成数据
        x = np.linspace(0, 10, 100)
        
        # 子图1: 折线图
        axes[0, 0].plot(x, np.sin(x), label='sin(x)', linewidth=1.2)
        axes[0, 0].plot(x, np.cos(x), label='cos(x)', linewidth=1.2, linestyle='--')
        axes[0, 0].set_xlabel('X')
        axes[0, 0].set_ylabel('Y')
        axes[0, 0].set_title('(a) 三角函数')
        axes[0, 0].legend(fontsize=6)
        axes[0, 0].grid(True, alpha=0.3)
        
        # 子图2: 散点图
        np.random.seed(42)
        x_scatter = np.random.randn(50)
        y_scatter = np.random.randn(50)
        axes[0, 1].scatter(x_scatter, y_scatter, alpha=0.6, s=20)
        axes[0, 1].set_xlabel('X')
        axes[0, 1].set_ylabel('Y')
        axes[0, 1].set_title('(b) 散点分布')
        axes[0, 1].grid(True, alpha=0.3)
        
        # 子图3: 直方图
        data = np.random.normal(0, 1, 1000)
        axes[1, 0].hist(data, bins=20, alpha=0.7, color='#0072B2', edgecolor='black')
        axes[1, 0].set_xlabel('值')
        axes[1, 0].set_ylabel('频数')
        axes[1, 0].set_title('(c) 数据分布')
        axes[1, 0].grid(True, axis='y', alpha=0.3)
        
        # 子图4: 箱线图
        data_box = [np.random.normal(0, 1, 100) for _ in range(3)]
        bp = axes[1, 1].boxplot(data_box, patch_artist=True)
        for patch in bp['boxes']:
            patch.set_facecolor('#56B4E9')
        axes[1, 1].set_xlabel('类别')
        axes[1, 1].set_ylabel('值')
        axes[1, 1].set_title('(d) 箱线图')
        axes[1, 1].grid(True, axis='y', alpha=0.3)
        
        plt.tight_layout()
        
        # 保存
        output_dir = "output/example3"
        import os
        os.makedirs(output_dir, exist_ok=True)
        paths = save_multiformat(
            fig,
            f"{output_dir}/nature_multiplot",
            formats=['png', 'svg', 'pdf', 'eps'],
            dpi=300
        )
        print(f"已保存文件:")
        for path in paths:
            print(f"  - {path}")
        
        plt.close(fig)
    
    print("\n")


def example_4_list_publications():
    """示例4: 列出支持的出版物类型"""
    print("=" * 60)
    print("示例4: 支持的出版物类型列表")
    print("=" * 60)

    publications = list_supported_publications()
    print("支持的出版物类型:")
    for pub in publications:
        info = get_publication_info(pub)
        print(f"\n{pub}:")
        print(f"  名称: {info['name']}")
        if info['name_en']:
            print(f"  英文名: {info['name_en']}")
        print(f"  描述: {info['description']}")

    print("\n")


def main():
    """主函数：运行所有示例"""
    print("\n")
    print("*" * 60)
    print("学术图表工具链使用示例")
    print("*" * 60)
    print("\n")
    
    # 运行示例
    example_4_list_journals()
    example_1_basic_usage()
    example_2_ieee_style()
    example_3_multi_subplot()
    
    print("*" * 60)
    print("所有示例运行完成！")
    print("输出文件保存在 output/ 目录下")
    print("*" * 60)


if __name__ == '__main__':
    main()
