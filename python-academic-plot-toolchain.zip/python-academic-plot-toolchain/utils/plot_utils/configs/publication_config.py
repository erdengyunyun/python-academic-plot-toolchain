"""
学术出版物配置模块

提供各类学术出版物的图表格式配置，包括：
- 期刊论文：《计算机工程与应用》、IEEE Transactions、Nature/Science等
- 学位论文：博士/硕士论文
- 教材书籍：学术专著、教材
- 技术报告：会议论文、技术文档

字体配置原则：
1. 中文出版物：中文用黑体/宋体，英文和数字用Arial
2. 英文出版物：使用Arial/Helvetica
3. 输出格式：PNG、SVG、png（位图）+ PDF/EPS（矢量图）
"""

from typing import Dict, Any, List, Tuple


# ====================
# 1. 计算机工程与应用期刊配置（中文期刊）
# ====================
# 中文期刊要求：
# - 图题文字：小5号方正书宋（约9pt）
# - 图中文字：6号方正书宋（约7.5pt）
# - 英文字体：Times New Roman
# - 坐标轴：刻度线朝内，标目格式为"物理量/单位"
# - 箭头：统一为"➝"
# - 线条：粗细统一
# - 格式：PNG、SVG、png（位图）+ PDF/EPS（矢量图）
CEA_CONFIG: Dict[str, Any] = {
    'name': '计算机工程与应用',
    'name_en': 'Computer Engineering and Applications',
    'description': '中文核心期刊，图题小5号方正书宋，图中6号方正书宋，英文Times New Roman，刻度线朝内',
    
    # 字体配置
    # 策略：中文方正书宋 + 英文Times New Roman，符合期刊最新要求
    'font': {
        # 主字体族：优先使用方正书宋（中文）和Times New Roman（英文）
        'family': ['FZShuSong-Z01', 'Times New Roman', 'serif'],
        
        # 衬线字体：方正书宋（中文，期刊要求），Times New Roman（英文）
        # 注意：CEA配置强制使用方正书宋，若不可用则回退到SimSun
        'serif': ['FZShuSong-Z01', 'SimSun', 'Times New Roman', 'STSong'],
        
        # 中文出版通用回退（当方正书宋不可用时使用SimSun）
        'chinese_fallback': ['SimSun', 'NSimSun', 'STSong'],
        
        # 无衬线字体：黑体（标题备用），Arial（兼容备用）
        'sans-serif': ['SimHei', 'Microsoft YaHei', 'Arial', 'Helvetica'],
        
        # 等宽字体：用于代码或等宽文本
        'monospace': ['Consolas', 'Courier New', 'SimSun'],
        
        # 字号配置
        # 图题：小5号（9pt），图中文字：6号（7.5pt）
        'titlesize': 9.0,      # 图题：小5号（9pt）
        'labelsize': 7.5,      # 坐标轴标签：6号（7.5pt）
        'ticksize': 7.5,       # 刻度标签：6号（7.5pt）
        'legendsize': 7.5,     # 图例：6号（7.5pt）
        'annotationsize': 7.5, # 注释：6号（7.5pt）
        
        # 字重
        'titleweight': 'normal',  # 期刊要求正常字重
        'labelweight': 'normal',
        
        # 字体嵌入设置
        'embed': True,        # 嵌入字体
        'subset': False,      # 不子集化（确保所有字符可用）
    },
    
    # 图形尺寸（单位：英寸，1英寸=2.54cm）
    # 提供基于页面比例的预设尺寸和具体尺寸两种选择
    'figure_size': {
        # 基于页面比例的标准尺寸（推荐）
        'full': (6.69, 8.0),      # 整页 (17cm x 20cm)
        'half': (6.69, 4.0),      # 半页 (17cm x 10cm)
        'quarter': (3.15, 4.0),   # 四分之一页 (8cm x 10cm)
        'eighth': (3.15, 2.0),    # 八分之一页 (8cm x 5cm)
        
        # 传统尺寸命名（保持向后兼容）
        'single': (3.15, 2.36),   # 8cm x 6cm (单栏)
        'double': (6.69, 2.76),   # 17cm x 7cm (双栏)
        'wide': (6.69, 3.94),     # 17cm x 10cm (宽幅)
        'square': (3.15, 3.15),   # 8cm x 8cm (方形)
    },
    
    # 线条样式（要求黑线图，线条光滑流畅，粗细统一）
    'line': {
        'linewidth': 1.0,         # 主线宽
        'grid_linewidth': 0.5,    # 网格线宽
        'border_linewidth': 0.8,  # 边框线宽
        'linestyles': ['-', '--', '-.', ':'],
        'uniform_width': True,    # 线条粗细统一
        'arrow_style': '->',      # 箭头样式：->
        'arrow_head_width': 0.3,  # 箭头头部宽度
        'arrow_head_length': 0.5, # 箭头头部长度
    },
    
    # 颜色配置（黑白印刷友好）
    'color': {
        'cycle': [
            '#000000',  # 黑色
            '#333333',  # 深灰
            '#666666',  # 中灰
            '#999999',  # 浅灰
            '#0000FF',  # 蓝色（如需彩色）
            '#FF0000',  # 红色（如需彩色）
        ],
        'primary': '#000000',
        'secondary': '#333333',
        'grid': '#CCCCCC',
        'background': '#FFFFFF',
    },
    
    # 输出配置
    # 用户要求：PNG、SVG、png三种格式
    'output': {
        'dpi': 300,                    # 分辨率≥300dpi
        'formats': ['png', 'svg', 'png', 'pdf', 'eps'],  # 支持格式
        'preferred_format': 'pdf',     # 矢量图优先
        'fonttype': 42,                # TrueType字体嵌入
        'facecolor': 'white',          # 背景色
        'edgecolor': 'none',           # 边缘色
    },
    
    # 样式配置
    'style': {
        'grid': True,
        'grid_alpha': 0.3,
        'grid_linestyle': '--',
        'spines_top': True,        # 显示上边框
        'spines_right': True,      # 显示右边框
        'spines_bottom': True,     # 显示下边框
        'spines_left': True,       # 显示左边框
        'tick_direction': 'in',    # 刻度线朝内（期刊要求）
        'tick_length': 3,          # 刻度线长度
        'tick_width': 0.8,         # 刻度线宽度
        'axis_label_format': 'physical_quantity/unit',  # 标目格式：物理量/单位
        'legend_location': 'best', # 图例位置：自动选择最佳位置
        'legend_frame': True,      # 图例带边框
        'legend_fancybox': False,  # 图例不使用圆角
        'legend_shadow': False,    # 图例无阴影
        'legend_draggable': False, # 图例不可拖动
    },
    
    # 图例配置（清晰且不压图）
    'legend': {
        'loc': 'best',             # 自动选择最佳位置
        'frameon': True,           # 显示边框
        'fancybox': False,         # 不使用圆角
        'shadow': False,           # 无阴影
        'ncol': 1,                 # 单列显示
        'fontsize': 7.5,           # 6号字
        'title_fontsize': 7.5,     # 6号字
        'borderpad': 0.5,          # 边框内边距
        'labelspacing': 0.3,       # 标签间距
        'handlelength': 2.0,       # 图例句柄长度
        'handletextpad': 0.5,      # 句柄与文本间距
    }
}


# ====================
# 2. IEEE Transactions配置（英文期刊）
# ====================
# IEEE要求：
# - 字体：Arial或Helvetica（无衬线）
# - 字号：标题8-12pt，刻度7-10pt
# - 分辨率：≥300dpi
# - 格式：PDF、EPS、TIFF
IEEE_CONFIG: Dict[str, Any] = {
    'name': 'IEEE Transactions',
    'description': 'IEEE Transactions系列期刊，Arial/Helvetica字体，≥300dpi',
    
    # 字体配置
    'font': {
        # 主字体族：Arial/Helvetica（IEEE首选），添加中文字体支持
        'family': ['Arial', 'Helvetica', 'sans-serif'],

        # 无衬线字体：优先中文字体，确保中英文混排正常显示
        'sans-serif': ['SimHei', 'Microsoft YaHei', 'Arial', 'Helvetica', 'DejaVu Sans', 'sans-serif'],
        
        # 衬线字体（备用）
        'serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
        
        # 等宽字体
        'monospace': ['Consolas', 'Courier New', 'monospace'],
        
        # 字号配置（IEEE要求较小字号）
        'titlesize': 9,       # 图题：9pt
        'labelsize': 8,       # 坐标轴标签：8pt
        'ticksize': 7,        # 刻度标签：7pt
        'legendsize': 7,      # 图例：7pt
        'annotationsize': 7,  # 注释：7pt
        
        # 字重
        'titleweight': 'bold',
        'labelweight': 'normal',
        
        # 字体嵌入
        'embed': True,
        'subset': False,
    },
    
    # 图形尺寸（IEEE单栏3.5英寸，双栏7英寸）
    'figure_size': {
        # 基于页面比例的标准尺寸（推荐）
        'full': (7.0, 8.0),       # 整页
        'half': (7.0, 4.0),       # 半页
        'quarter': (3.5, 4.0),    # 四分之一页
        'eighth': (3.5, 2.0),     # 八分之一页
        
        # 传统尺寸命名
        'single': (3.5, 2.625),   # 单栏
        'double': (7.0, 2.625),   # 双栏
        'wide': (7.0, 4.0),       # 宽幅
        'square': (3.5, 3.5),     # 方形
    },
    
    # 线条样式
    'line': {
        'linewidth': 1.2,
        'grid_linewidth': 0.5,
        'border_linewidth': 1.0,
        'linestyles': ['-', '--', '-.', ':'],
    },
    
    # 颜色配置（彩色印刷友好）
    'color': {
        'cycle': [
            '#0066CC',  # 蓝色
            '#CC0000',  # 红色
            '#009900',  # 绿色
            '#FF9900',  # 橙色
            '#9900CC',  # 紫色
            '#00CCCC',  # 青色
        ],
        'primary': '#0066CC',
        'secondary': '#CC0000',
        'grid': '#E0E0E0',
        'background': '#FFFFFF',
    },
    
    # 输出配置
    'output': {
        'dpi': 300,
        'formats': ['png', 'svg', 'png', 'pdf', 'eps', 'tiff'],
        'preferred_format': 'pdf',
        'fonttype': 42,
        'facecolor': 'white',
        'edgecolor': 'none',
    },
    
    # 样式配置
    'style': {
        'grid': True,
        'grid_alpha': 0.3,
        'grid_linestyle': ':',
        'spines_top': False,
        'spines_right': False,
        'tick_direction': 'in',
    }
}


# ====================
# 3. Nature/Science配置（英文期刊）
# ====================
# Nature/Science要求：
# - 字体：Arial或Helvetica
# - 颜色：RGB模式，避免红绿对比
# - 分辨率：≥300dpi
NATURE_CONFIG: Dict[str, Any] = {
    'name': 'Nature/Science',
    'description': 'Nature/Science系列期刊，Arial/Helvetica字体，RGB模式，≥300dpi',
    
    # 字体配置
    'font': {
        # 主字体族：Arial/Helvetica，添加中文字体支持
        'family': ['Arial', 'Helvetica', 'sans-serif'],

        # 无衬线字体：优先中文字体，确保中英文混排正常显示
        'sans-serif': ['SimHei', 'Microsoft YaHei', 'Arial', 'Helvetica', 'DejaVu Sans', 'sans-serif'],
        
        # 衬线字体（备用）
        'serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
        
        # 等宽字体
        'monospace': ['Consolas', 'Courier New', 'monospace'],
        
        # 字号配置
        'titlesize': 10,
        'labelsize': 8,
        'ticksize': 7,
        'legendsize': 7,
        'annotationsize': 7,
        
        # 字重
        'titleweight': 'bold',
        'labelweight': 'normal',
        
        # 字体嵌入
        'embed': True,
        'subset': False,
    },
    
    # 图形尺寸
    'figure_size': {
        # 基于页面比例的标准尺寸（推荐）
        'full': (7.09, 8.0),      # 整页
        'half': (7.09, 4.0),      # 半页
        'quarter': (3.54, 4.0),   # 四分之一页
        'eighth': (3.54, 2.0),    # 八分之一页
        
        # 传统尺寸命名
        'single': (3.54, 2.66),   # 9cm x 6.75cm
        'double': (7.09, 2.66),   # 18cm x 6.75cm
        'wide': (7.09, 4.72),     # 18cm x 12cm
        'square': (3.54, 3.54),   # 9cm x 9cm
    },
    
    # 线条样式
    'line': {
        'linewidth': 1.2,
        'grid_linewidth': 0.5,
        'border_linewidth': 1.0,
        'linestyles': ['-', '--', '-.', ':'],
    },
    
    # 颜色配置（避免红绿对比，色盲友好）
    'color': {
        'cycle': [
            '#0072B2',  # 蓝色
            '#D55E00',  # 橙红色
            '#009E73',  # 青绿色（避免纯绿）
            '#CC79A7',  # 粉色
            '#F0E442',  # 黄色
            '#56B4E9',  # 天蓝色
        ],
        'primary': '#0072B2',
        'secondary': '#D55E00',
        'grid': '#E0E0E0',
        'background': '#FFFFFF',
    },
    
    # 输出配置
    'output': {
        'dpi': 300,
        'formats': ['png', 'svg', 'png', 'pdf', 'eps', 'tiff'],
        'preferred_format': 'pdf',
        'fonttype': 42,
        'facecolor': 'white',
        'edgecolor': 'none',
    },
    
    # 样式配置
    'style': {
        'grid': True,
        'grid_alpha': 0.3,
        'grid_linestyle': '--',
        'spines_top': False,
        'spines_right': False,
        'tick_direction': 'in',
    }
}


# ====================
# 4. 通用配置（默认配置）
# ====================
# 当不指定期刊时使用，采用保守设置
DEFAULT_CONFIG: Dict[str, Any] = {
    'name': 'Default',
    'description': '默认配置，兼容中英文，支持多种格式输出',
    
    # 字体配置：兼容中英文
    'font': {
        'family': ['Arial', 'SimHei', 'sans-serif'],
        'sans-serif': ['Arial', 'SimHei', 'Microsoft YaHei', 'Helvetica'],
        'serif': ['Times New Roman', 'SimSun', 'STSong'],
        'monospace': ['Consolas', 'Courier New'],
        
        'titlesize': 10,
        'labelsize': 9,
        'ticksize': 8,
        'legendsize': 8,
        'annotationsize': 8,
        
        'titleweight': 'bold',
        'labelweight': 'normal',
        
        'embed': True,
        'subset': False,
    },
    
    # 图形尺寸
    'figure_size': {
        'single': (3.5, 2.5),
        'double': (7.0, 2.5),
        'wide': (7.0, 4.0),
        'square': (3.5, 3.5),
    },
    
    # 线条样式
    'line': {
        'linewidth': 1.0,
        'grid_linewidth': 0.5,
        'border_linewidth': 0.8,
        'linestyles': ['-', '--', '-.', ':'],
    },
    
    # 颜色配置 - 色盲友好配色方案（基于Wong, 2011）
    # 蓝-橙-青绿-粉-黄-浅蓝，完全避免红绿对比
    'color': {
        'cycle': [
            '#0072B2',  # 蓝 - 主色
            '#D55E00',  # 橙 - 对比色
            '#009E73',  # 青绿 - 辅助色
            '#CC79A7',  # 粉 - 强调色
            '#F0E442',  # 黄 - 高亮色
            '#56B4E9',  # 浅蓝 - 补充色
        ],
        'primary': '#0072B2',
        'secondary': '#D55E00',
        'grid': '#E0E0E0',
        'background': '#FFFFFF',
    },
    
    # 输出配置：默认支持PNG、SVG、png
    'output': {
        'dpi': 300,
        'formats': ['png', 'svg', 'png', 'pdf', 'eps'],
        'preferred_format': 'png',
        'fonttype': 42,
        'facecolor': 'white',
        'edgecolor': 'none',
    },
    
    # 样式配置
    'style': {
        'grid': True,
        'grid_alpha': 0.3,
        'grid_linestyle': '--',
        'spines_top': False,
        'spines_right': False,
        'tick_direction': 'in',
    }
}


# ====================
# 4. 学位论文配置
# ====================
# 学位论文通常要求：
# - 图表清晰，便于阅读
# - 支持彩色和黑白打印
# - 字体规范，中文用黑体/宋体，英文用Times New Roman
THESIS_CONFIG: Dict[str, Any] = {
    'name': '学位论文',
    'name_en': 'Academic Thesis/Dissertation',
    'description': '博士/硕士学位论文，支持彩色和黑白打印',
    
    'font': {
        'family': ['SimHei', 'Times New Roman', 'serif'],
        'sans-serif': ['SimHei', 'Microsoft YaHei', 'Arial'],
        'serif': ['SimSun', 'Times New Roman', 'STSong'],
        'titlesize': 12,
        'labelsize': 11,
        'ticksize': 10,
        'legendsize': 10,
    },
    
    'figure_size': {
        'full': (6.0, 8.0),
        'half': (6.0, 4.0),
        'quarter': (3.0, 4.0),
        'eighth': (3.0, 2.0),
        'single': (3.0, 2.25),
        'double': (6.0, 2.25),
    },
    
    'color': {
        'cycle': [
            '#000000', '#E69F00', '#56B4E9', '#009E73',
            '#F0E442', '#0072B2', '#D55E00', '#CC79A7'
        ],
        'primary': '#000000',
        'secondary': '#E69F00',
    },
    
    'output': {
        'dpi': 300,
        'formats': ['png', 'svg', 'pdf', 'eps'],
        'preferred_format': 'pdf',
    },
    
    'style': {
        'grid': True,
        'grid_alpha': 0.3,
        'spines_top': False,
        'spines_right': False,
    }
}


# ====================
# 5. 教材书籍配置
# ====================
# 教材书籍通常要求：
# - 清晰易读，适合印刷
# - 黑白印刷友好
# - 字体规范，层次分明
BOOK_CONFIG: Dict[str, Any] = {
    'name': '教材书籍',
    'name_en': 'Textbook/Monograph',
    'description': '学术专著、教材，黑白印刷友好',
    
    'font': {
        'family': ['SimSun', 'Times New Roman', 'serif'],
        'sans-serif': ['SimHei', 'Arial'],
        'serif': ['SimSun', 'Times New Roman', 'STSong'],
        'titlesize': 10,
        'labelsize': 9,
        'ticksize': 8,
        'legendsize': 8,
    },
    
    'figure_size': {
        'full': (5.5, 7.0),
        'half': (5.5, 3.5),
        'quarter': (2.75, 3.5),
        'eighth': (2.75, 1.75),
        'single': (2.75, 2.0),
        'double': (5.5, 2.0),
    },
    
    'color': {
        'cycle': [
            '#000000', '#333333', '#666666', '#999999',
            '#0000FF', '#CC0000', '#009900'
        ],
        'primary': '#000000',
        'secondary': '#333333',
    },
    
    'output': {
        'dpi': 300,
        'formats': ['png', 'pdf', 'eps'],
        'preferred_format': 'pdf',
    },
    
    'style': {
        'grid': False,
        'spines_top': False,
        'spines_right': False,
    }
}


# ====================
# 出版物配置映射
# ====================
PUBLICATION_CONFIGS: Dict[str, Dict[str, Any]] = {
    # 期刊论文
    'cea': CEA_CONFIG,
    'computer_engineering_and_applications': CEA_CONFIG,
    '计算机工程与应用': CEA_CONFIG,
    
    'ieee': IEEE_CONFIG,
    'ieee_transactions': IEEE_CONFIG,
    
    'nature': NATURE_CONFIG,
    'science': NATURE_CONFIG,
    'nature_science': NATURE_CONFIG,
    
    # 学位论文
    'thesis': THESIS_CONFIG,
    'dissertation': THESIS_CONFIG,
    '学位论文': THESIS_CONFIG,
    '博士论文': THESIS_CONFIG,
    '硕士论文': THESIS_CONFIG,
    
    # 教材书籍
    'book': BOOK_CONFIG,
    'textbook': BOOK_CONFIG,
    '教材': BOOK_CONFIG,
    '书籍': BOOK_CONFIG,
    '专著': BOOK_CONFIG,
    
    # 默认配置
    'default': DEFAULT_CONFIG,
}


def get_publication_config(publication_name: str) -> Dict[str, Any]:
    """
    获取指定出版物的配置
    
    Args:
        publication_name: 出版物名称（支持期刊、学位论文、教材书籍等）
        
    Returns:
        Dict[str, Any]: 出版物配置字典
        
    Raises:
        ValueError: 如果出版物名称不存在
    """
    publication_name_lower = publication_name.lower().replace(' ', '_')
    
    if publication_name in PUBLICATION_CONFIGS:
        return PUBLICATION_CONFIGS[publication_name]
    elif publication_name_lower in PUBLICATION_CONFIGS:
        return PUBLICATION_CONFIGS[publication_name_lower]
    else:
        # 返回默认配置而不是报错
        print(f"警告: 未知出版物 '{publication_name}'，使用默认配置")
        return DEFAULT_CONFIG


# 保持向后兼容的别名
get_journal_config = get_publication_config


def list_supported_publications() -> List[str]:
    """
    获取支持的出版物列表
    
    Returns:
        List[str]: 出版物代码列表
    """
    return ['cea', 'ieee', 'nature', 'thesis', 'book', 'default']


# 保持向后兼容的别名
list_supported_journals = list_supported_publications


def get_publication_info(publication_name: str) -> Dict[str, str]:
    """
    获取出版物信息
    
    Args:
        publication_name: 出版物名称
        
    Returns:
        Dict[str, str]: 期刊信息（名称、描述等）
    """
    config = get_journal_config(journal_name)
    return {
        'name': config.get('name', ''),
        'name_en': config.get('name_en', ''),
        'description': config.get('description', ''),
    }


def get_font_config(journal_name: str) -> Dict[str, Any]:
    """
    获取期刊字体配置
    
    Args:
        journal_name: 期刊名称
        
    Returns:
        Dict[str, Any]: 字体配置字典
    """
    config = get_journal_config(journal_name)
    return config.get('font', DEFAULT_CONFIG['font'])


def get_output_formats(journal_name: str) -> List[str]:
    """
    获取期刊支持的输出格式
    
    Args:
        journal_name: 期刊名称
        
    Returns:
        List[str]: 支持的格式列表
    """
    config = get_journal_config(journal_name)
    return config.get('output', {}).get('formats', ['png', 'svg', 'png'])
