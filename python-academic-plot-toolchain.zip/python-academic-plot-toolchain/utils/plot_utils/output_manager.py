"""
多格式输出与合规性校验模块

提供图表的多格式输出、矢量优化和出版合规性校验功能。
"""

import os
import io
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass

import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

from .exceptions import OutputError, ValidationError


@dataclass
class ComplianceReport:
    """合规性检查报告"""
    passed: bool
    checks: Dict[str, Dict[str, Any]]
    errors: List[str]
    warnings: List[str]
    
    def __str__(self) -> str:
        lines = ["=" * 50, "合规性检查报告", "=" * 50]
        lines.append(f"总体结果: {'通过' if self.passed else '未通过'}")
        lines.append("")
        
        if self.checks:
            lines.append("检查项:")
            for check_name, result in self.checks.items():
                status = "通过" if result.get('passed', False) else "未通过"
                lines.append(f"  - {check_name}: {status}")
                if 'value' in result:
                    lines.append(f"    值: {result['value']}")
                if 'message' in result:
                    lines.append(f"    信息: {result['message']}")
        
        if self.errors:
            lines.append("")
            lines.append("错误:")
            for error in self.errors:
                lines.append(f"  - {error}")
        
        if self.warnings:
            lines.append("")
            lines.append("警告:")
            for warning in self.warnings:
                lines.append(f"  - {warning}")
        
        return "\n".join(lines)


class OutputManager:
    """
    输出管理类
    
    负责图表的多格式输出、矢量优化和合规性校验。
    """
    
    # 支持的输出格式
    SUPPORTED_FORMATS = ['png', 'pdf', 'svg', 'eps', 'tiff', 'jpg']
    
    # 矢量格式
    VECTOR_FORMATS = ['pdf', 'svg', 'eps']
    
    # 位图格式
    RASTER_FORMATS = ['png', 'tiff', 'jpg']
    
    def __init__(self, default_dpi: int = 300) -> None:
        """
        初始化输出管理器
        
        Args:
            default_dpi: 默认分辨率
        """
        self.default_dpi = default_dpi
    
    def save_figure(self,
                   fig: plt.Figure,
                   filepath: Union[str, Path],
                   format: Optional[str] = None,
                   dpi: Optional[int] = None,
                   **kwargs) -> Path:
        """
        保存图表到文件
        
        Args:
            fig: 图表对象
            filepath: 文件路径
            format: 文件格式（自动从扩展名推断）
            dpi: 分辨率
            **kwargs: 其他保存参数
            
        Returns:
            Path: 保存的文件路径
            
        Raises:
            OutputError: 保存失败
        """
        filepath = Path(filepath)
        
        # 确保目录存在
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        # 推断格式
        if format is None:
            format = filepath.suffix.lstrip('.').lower()
        
        if format not in self.SUPPORTED_FORMATS:
            raise OutputError(f"不支持的格式: {format}")
        
        dpi = dpi or self.default_dpi
        
        try:
            # 根据格式设置特定参数
            save_kwargs = self._get_format_kwargs(format, dpi, **kwargs)
            fig.savefig(filepath, **save_kwargs)
            
            # 矢量格式优化
            if format in self.VECTOR_FORMATS:
                self._optimize_vector(filepath, format)
            
            return filepath
            
        except Exception as e:
            raise OutputError(f"保存图表失败: {e}")
    
    def save_multiformat(self,
                        fig: plt.Figure,
                        base_path: Union[str, Path],
                        formats: List[str] = None,
                        dpi: Optional[int] = None,
                        organize_by_format: bool = True,
                        **kwargs) -> List[Path]:
        """
        保存图表到多种格式
        
        Args:
            fig: 图表对象
            base_path: 基础文件路径（不含扩展名）
            formats: 格式列表，默认['png', 'pdf']
            dpi: 分辨率
            organize_by_format: 是否按格式分子目录存放，默认True
            **kwargs: 其他保存参数
            
        Returns:
            List[Path]: 保存的文件路径列表
        """
        if formats is None:
            formats = ['png', 'pdf']
        
        base_path = Path(base_path)
        saved_paths = []
        
        for fmt in formats:
            if organize_by_format:
                # 按格式分子目录：output/example1/png/figure.png
                filepath = base_path.parent / fmt / f"{base_path.name}.{fmt}"
            else:
                # 传统方式：output/example1/figure.png
                filepath = base_path.parent / f"{base_path.name}.{fmt}"
            
            try:
                saved_path = self.save_figure(fig, filepath, fmt, dpi, **kwargs)
                saved_paths.append(saved_path)
            except OutputError as e:
                print(f"警告: 保存{fmt}格式失败: {e}")
        
        return saved_paths
    
    def _get_format_kwargs(self, 
                          format: str, 
                          dpi: int,
                          **kwargs) -> Dict[str, Any]:
        """
        获取格式特定的保存参数
        
        Args:
            format: 文件格式
            dpi: 分辨率
            **kwargs: 用户自定义参数
            
        Returns:
            Dict[str, Any]: 保存参数
        """
        base_kwargs = {
            'dpi': dpi,
            'bbox_inches': 'tight',
            'pad_inches': 0.1,
            'facecolor': 'white',
            'edgecolor': 'none',
        }
        
        # 格式特定参数
        format_kwargs = {
            'png': {
                'format': 'png',
                'transparent': False,
            },
            'jpg': {
                'format': 'jpg',
            },
            'jpeg': {
                'format': 'jpeg',
            },
            'pdf': {
                'format': 'pdf',
                'metadata': {
                    'Creator': 'Academic Plots Toolchain',
                    'Producer': 'Matplotlib PDF Writer',
                }
            },
            'svg': {
                'format': 'svg',
            },
            'eps': {
                'format': 'eps',
                'papertype': 'letter',
            },
            'tiff': {
                'format': 'tiff',
            }
        }
        
        base_kwargs.update(format_kwargs.get(format, {}))
        base_kwargs.update(kwargs)
        
        return base_kwargs
    
    def _optimize_vector(self, filepath: Path, format: str) -> None:
        """
        优化矢量图文件
        
        Args:
            filepath: 文件路径
            format: 文件格式
        """
        if format == 'svg':
            self._optimize_svg(filepath)
        elif format == 'pdf':
            self._optimize_pdf(filepath)
    
    def _optimize_svg(self, filepath: Path) -> None:
        """
        使用Inkscape优化SVG文件

        Args:
            filepath: SVG文件路径
        """
        try:
            # 根据操作系统确定Inkscape命令
            import sys
            if sys.platform == 'win32':
                # Windows系统
                inkscape_cmd = 'inkscape.exe'
            else:
                # Linux/macOS系统
                inkscape_cmd = 'inkscape'

            # 检查Inkscape是否可用
            result = subprocess.run(
                [inkscape_cmd, '--version'],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode != 0:
                return

            # 创建临时文件
            with tempfile.NamedTemporaryFile(suffix='.svg', delete=False) as tmp:
                tmp_path = tmp.name

            try:
                # 使用Inkscape优化（命令格式在所有平台上相同）
                subprocess.run([
                    inkscape_cmd,
                    '--export-type=svg',
                    '--export-plain-svg',
                    '--export-text-to-path',
                    '--export-filename', tmp_path,
                    str(filepath)
                ], check=True, timeout=30)

                # 替换原文件
                import shutil
                shutil.move(tmp_path, filepath)

            finally:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)

        except (subprocess.SubprocessError, FileNotFoundError):
            # Inkscape不可用，跳过优化
            pass
    
    def _optimize_pdf(self, filepath: Path) -> None:
        """
        优化PDF文件
        
        Args:
            filepath: PDF文件路径
        """
        # 可以在这里添加PDF优化逻辑
        # 例如使用PyPDF2或ghostscript进行压缩
        pass
    
    def verify_compliance(self,
                         fig: plt.Figure,
                         config: Dict[str, Any],
                         strict: bool = False) -> ComplianceReport:
        """
        校验图表的出版合规性
        
        Args:
            fig: 图表对象
            config: 配置字典
            strict: 是否严格模式（严格模式下警告视为错误）
            
        Returns:
            ComplianceReport: 合规性检查报告
        """
        checks = {}
        errors = []
        warnings = []
        
        # 1. 检查分辨率
        dpi_check = self._check_resolution(fig, config)
        checks['resolution'] = dpi_check
        if not dpi_check['passed']:
            if strict:
                errors.append(dpi_check['message'])
            else:
                warnings.append(dpi_check['message'])
        
        # 2. 检查字体
        font_check = self._check_fonts(fig, config)
        checks['fonts'] = font_check
        if not font_check['passed']:
            if strict:
                errors.append(font_check['message'])
            else:
                warnings.append(font_check['message'])
        
        # 3. 检查图形尺寸
        size_check = self._check_figure_size(fig, config)
        checks['figure_size'] = size_check
        if not size_check['passed']:
            warnings.append(size_check['message'])
        
        # 4. 检查标签完整性
        label_check = self._check_labels(fig)
        checks['labels'] = label_check
        if not label_check['passed']:
            warnings.append(label_check['message'])
        
        # 确定总体结果
        passed = len(errors) == 0
        
        return ComplianceReport(
            passed=passed,
            checks=checks,
            errors=errors,
            warnings=warnings
        )
    
    def _check_resolution(self, 
                         fig: plt.Figure, 
                         config: Dict[str, Any]) -> Dict[str, Any]:
        """检查分辨率"""
        required_dpi = config.get('output', {}).get('dpi', 300)
        actual_dpi = fig.dpi
        
        passed = actual_dpi >= required_dpi
        
        return {
            'passed': passed,
            'value': f"{actual_dpi} DPI",
            'required': f"{required_dpi} DPI",
            'message': f"分辨率检查: {actual_dpi} DPI (要求≥{required_dpi} DPI)"
        }
    
    def _check_fonts(self, 
                    fig: plt.Figure, 
                    config: Dict[str, Any]) -> Dict[str, Any]:
        """检查字体配置"""
        required_fonts = config.get('font', {}).get('family', [])
        
        # 获取实际使用的字体
        used_fonts = set()
        for ax in fig.axes:
            for text in ax.texts:
                font_family = text.get_fontfamily()
                # 处理字体可能是列表的情况
                if isinstance(font_family, list):
                    used_fonts.update(font_family)
                else:
                    used_fonts.add(font_family)
        
        # 简化检查：只检查是否有字体配置
        passed = len(required_fonts) > 0
        
        return {
            'passed': passed,
            'value': list(used_fonts),
            'required': required_fonts,
            'message': f"字体配置检查: 要求{required_fonts}"
        }
    
    def _check_figure_size(self, 
                          fig: plt.Figure, 
                          config: Dict[str, Any]) -> Dict[str, Any]:
        """检查图形尺寸"""
        # 获取实际尺寸（英寸）
        width, height = fig.get_size_inches()
        
        # 获取配置中的尺寸
        figure_sizes = config.get('figure_size', {})
        
        # 简化检查：只记录尺寸信息
        return {
            'passed': True,
            'value': f"{width:.2f} x {height:.2f} inches",
            'available_sizes': list(figure_sizes.keys()),
            'message': f"图形尺寸: {width:.2f} x {height:.2f} inches"
        }
    
    def _check_labels(self, fig: plt.Figure) -> Dict[str, Any]:
        """检查标签完整性"""
        missing_labels = []
        
        for i, ax in enumerate(fig.axes):
            if not ax.get_xlabel():
                missing_labels.append(f"子图{i+1}缺少X轴标签")
            if not ax.get_ylabel():
                missing_labels.append(f"子图{i+1}缺少Y轴标签")
        
        passed = len(missing_labels) == 0
        
        return {
            'passed': passed,
            'value': "完整" if passed else f"缺少{len(missing_labels)}个标签",
            'missing': missing_labels,
            'message': "标签完整" if passed else f"标签不完整: {', '.join(missing_labels)}"
        }


# ====================
# 便捷函数
# ====================

def save_figure(fig: plt.Figure,
               filepath: Union[str, Path],
               format: Optional[str] = None,
               dpi: int = 300,
               **kwargs) -> Path:
    """
    保存图表的便捷函数
    
    Args:
        fig: 图表对象
        filepath: 文件路径
        format: 文件格式
        dpi: 分辨率
        **kwargs: 其他参数
        
    Returns:
        Path: 保存的文件路径
    """
    manager = OutputManager(default_dpi=dpi)
    return manager.save_figure(fig, filepath, format, dpi, **kwargs)


def save_multiformat(fig: plt.Figure,
                    base_path: Union[str, Path],
                    formats: List[str] = None,
                    dpi: int = 300,
                    **kwargs) -> List[Path]:
    """
    保存多格式的便捷函数
    
    Args:
        fig: 图表对象
        base_path: 基础文件路径
        formats: 格式列表
        dpi: 分辨率
        **kwargs: 其他参数
        
    Returns:
        List[Path]: 保存的文件路径列表
    """
    manager = OutputManager(default_dpi=dpi)
    return manager.save_multiformat(fig, base_path, formats, dpi, **kwargs)


def check_compliance(fig: plt.Figure,
                    config: Dict[str, Any],
                    strict: bool = False) -> ComplianceReport:
    """
    合规性检查的便捷函数
    
    Args:
        fig: 图表对象
        config: 配置字典
        strict: 是否严格模式
        
    Returns:
        ComplianceReport: 合规性检查报告
    """
    manager = OutputManager()
    return manager.verify_compliance(fig, config, strict)