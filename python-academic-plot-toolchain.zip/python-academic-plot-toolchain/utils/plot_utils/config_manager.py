"""
配置管理模块

提供YAML/JSON配置加载、验证和上下文管理功能。
实现"全局配置+局部重载"的灵活管控机制。
"""

import os
import json
import copy
from typing import Dict, Any, Optional, Union
from contextlib import contextmanager
from pathlib import Path

import matplotlib.pyplot as plt

from .exceptions import ConfigError, ValidationError
from .font_manager import FontManager


class ConfigManager:
    """
    配置管理类
    
    负责配置的加载、验证、合并和持久化。
    支持YAML/JSON格式的配置文件。
    """
    
    def __init__(self) -> None:
        """初始化配置管理器"""
        self._global_config: Dict[str, Any] = {}
        self._config_cache: Dict[str, Any] = {}
        
    def load_config(self, config_path: Union[str, Path]) -> Dict[str, Any]:
        """
        加载配置文件
        
        Args:
            config_path: 配置文件路径（支持.yaml, .yml, .json）
            
        Returns:
            Dict[str, Any]: 配置字典
            
        Raises:
            ConfigError: 配置文件加载失败
        """
        config_path = Path(config_path)
        
        if not config_path.exists():
            raise ConfigError(f"配置文件不存在: {config_path}")
        
        # 检查缓存
        cache_key = str(config_path)
        if cache_key in self._config_cache:
            return copy.deepcopy(self._config_cache[cache_key])
        
        try:
            if config_path.suffix in ['.yaml', '.yml']:
                config = self._load_yaml(config_path)
            elif config_path.suffix == '.json':
                config = self._load_json(config_path)
            else:
                raise ConfigError(f"不支持的配置文件格式: {config_path.suffix}")
            
            # 验证配置
            self.validate_config(config)
            
            # 缓存配置
            self._config_cache[cache_key] = copy.deepcopy(config)
            
            return config
            
        except Exception as e:
            raise ConfigError(f"加载配置文件失败: {e}")
    
    def _load_yaml(self, path: Path) -> Dict[str, Any]:
        """加载YAML配置文件"""
        try:
            import yaml
            with open(path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f) or {}
        except ImportError:
            raise ConfigError("加载YAML配置需要安装PyYAML: pip install pyyaml")
    
    def _load_json(self, path: Path) -> Dict[str, Any]:
        """加载JSON配置文件"""
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def validate_config(self, config: Dict[str, Any]) -> bool:
        """
        验证配置的有效性
        
        Args:
            config: 配置字典
            
        Returns:
            bool: 配置是否有效
            
        Raises:
            ValidationError: 配置验证失败
        """
        # 验证字体配置
        if 'font' in config:
            font_config = config['font']
            required_font_keys = ['family', 'titlesize', 'labelsize', 'ticksize']
            for key in required_font_keys:
                if key not in font_config:
                    raise ValidationError(f"字体配置缺少必要字段: {key}")
            
            # 验证字号为正整数
            for size_key in ['titlesize', 'labelsize', 'ticksize', 'legendsize']:
                if size_key in font_config:
                    size = font_config[size_key]
                    if not isinstance(size, (int, float)) or size <= 0:
                        raise ValidationError(f"字号必须为正数: {size_key}={size}")
        
        # 验证图形尺寸
        if 'figure_size' in config:
            for size_name, size_tuple in config['figure_size'].items():
                if not isinstance(size_tuple, (list, tuple)) or len(size_tuple) != 2:
                    raise ValidationError(f"图形尺寸格式错误: {size_name}={size_tuple}")
                if not all(isinstance(x, (int, float)) and x > 0 for x in size_tuple):
                    raise ValidationError(f"图形尺寸必须为正数: {size_name}={size_tuple}")
        
        # 验证DPI
        if 'output' in config and 'dpi' in config['output']:
            dpi = config['output']['dpi']
            if not isinstance(dpi, int) or dpi < 72:
                raise ValidationError(f"DPI必须≥72: dpi={dpi}")
        
        return True
    
    def merge_configs(self, global_config: Dict[str, Any], 
                     local_config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        合并全局配置和局部配置
        
        局部配置会重载全局配置中的同名参数。
        
        Args:
            global_config: 全局配置
            local_config: 局部配置（可选）
            
        Returns:
            Dict[str, Any]: 合并后的配置
        """
        if local_config is None:
            return copy.deepcopy(global_config)
        
        merged = copy.deepcopy(global_config)
        
        def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> None:
            for key, value in override.items():
                if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                    _deep_merge(base[key], value)
                else:
                    base[key] = copy.deepcopy(value)
        
        _deep_merge(merged, local_config)
        return merged
    
    def save_config(self, config: Dict[str, Any], 
                   output_path: Union[str, Path],
                   format: str = 'json') -> None:
        """
        保存配置到文件
        
        Args:
            config: 配置字典
            output_path: 输出路径
            format: 输出格式（'json'或'yaml'）
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if format == 'json':
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
        elif format in ['yaml', 'yml']:
            try:
                import yaml
                with open(output_path, 'w', encoding='utf-8') as f:
                    yaml.dump(config, f, allow_unicode=True, default_flow_style=False)
            except ImportError:
                raise ConfigError("保存YAML配置需要安装PyYAML: pip install pyyaml")
        else:
            raise ConfigError(f"不支持的输出格式: {format}")


class PlotConfigContext:
    """
    绘图配置上下文管理器
    
    实现配置的原子化切换，避免跨图表配置污染。
    支持"全局配置+局部重载"的灵活管控机制。
    
    使用示例:
        >>> with PlotConfigContext(global_config, local_config) as ctx:
        ...     fig, ax = plt.subplots()
        ...     ax.plot([1, 2, 3], [1, 4, 9])
        ...     plt.show()
        # 退出上下文后，配置自动恢复
    """
    
    def __init__(self, 
                 global_config: Dict[str, Any],
                 local_config: Optional[Dict[str, Any]] = None,
                 config_manager: Optional[ConfigManager] = None) -> None:
        """
        初始化配置上下文
        
        Args:
            global_config: 全局配置字典或配置文件路径
            local_config: 局部配置字典（可选）
            config_manager: 配置管理器实例（可选）
        """
        self.config_manager = config_manager or ConfigManager()
        
        # 加载全局配置
        if isinstance(global_config, (str, Path)):
            self.global_config = self.config_manager.load_config(global_config)
        else:
            self.global_config = copy.deepcopy(global_config)
        
        # 加载局部配置
        if isinstance(local_config, (str, Path)):
            self.local_config = self.config_manager.load_config(local_config)
        else:
            self.local_config = copy.deepcopy(local_config) if local_config else None
        
        # 合并配置
        self.merged_config = self.config_manager.merge_configs(
            self.global_config, self.local_config
        )
        
        # 保存原始配置
        self._original_rcparams: Optional[Dict[str, Any]] = None
    
    def __enter__(self) -> 'PlotConfigContext':
        """
        进入上下文，应用配置
        
        Returns:
            PlotConfigContext: 当前上下文实例
        """
        # 保存原始配置
        self._original_rcparams = plt.rcParams.copy()
        
        # 应用合并后的配置
        self._apply_config(self.merged_config)
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """
        退出上下文，恢复原始配置
        
        Args:
            exc_type: 异常类型
            exc_val: 异常值
            exc_tb: 异常追踪
        """
        # 恢复原始配置
        if self._original_rcparams is not None:
            plt.rcParams.update(self._original_rcparams)
    
    def _apply_config(self, config: Dict[str, Any]) -> None:
        """
        应用配置到Matplotlib，使用智能字体选择
        
        Args:
            config: 配置字典
        """
        # 应用字体配置
        if 'font' in config:
            # 使用字体管理器获取实际可用的字体配置
            font = FontManager.get_font_config(config['font'])

            # 设置字体族（关键：确保中文字体在前）
            font_family = font.get('family', ['sans-serif'])
            plt.rcParams['font.family'] = font_family

            # 设置无衬线字体族（用于中文显示，已过滤掉不可用字体）
            sans_serif = font.get('sans-serif', ['Arial', 'Helvetica'])
            plt.rcParams['font.sans-serif'] = sans_serif

            # 设置衬线字体族
            serif = font.get('serif', ['Times New Roman'])
            plt.rcParams['font.serif'] = serif

            # 设置等宽字体
            monospace = font.get('monospace', ['Consolas', 'Courier New'])
            plt.rcParams['font.monospace'] = monospace
            
            # 设置字号
            plt.rcParams['axes.titlesize'] = font.get('titlesize', 12)
            plt.rcParams['axes.labelsize'] = font.get('labelsize', 10)
            plt.rcParams['xtick.labelsize'] = font.get('ticksize', 9)
            plt.rcParams['ytick.labelsize'] = font.get('ticksize', 9)
            plt.rcParams['legend.fontsize'] = font.get('legendsize', 9)
            
            # 设置字重
            plt.rcParams['axes.titleweight'] = font.get('titleweight', 'bold')
            plt.rcParams['axes.labelweight'] = font.get('labelweight', 'normal')
            
            # 设置数学文本字体（避免数学公式使用特殊字体）
            plt.rcParams['mathtext.fontset'] = 'custom'
            plt.rcParams['mathtext.rm'] = 'Arial'
            plt.rcParams['mathtext.it'] = 'Arial:italic'
            plt.rcParams['mathtext.bf'] = 'Arial:bold'
            
            # 解决负号显示问题（使用ASCII减号而不是Unicode减号）
            plt.rcParams['axes.unicode_minus'] = False
        
        # 应用线条配置
        if 'line' in config:
            line = config['line']
            plt.rcParams['lines.linewidth'] = line.get('linewidth', 1.5)
            plt.rcParams['axes.linewidth'] = line.get('border_linewidth', 1.0)
            plt.rcParams['grid.linewidth'] = line.get('grid_linewidth', 0.5)
        
        # 应用颜色配置
        if 'color' in config and 'cycle' in config['color']:
            from cycler import cycler
            plt.rcParams['axes.prop_cycle'] = cycler(color=config['color']['cycle'])
        
        # 应用输出配置
        if 'output' in config:
            output = config['output']
            plt.rcParams['savefig.dpi'] = output.get('dpi', 300)
            plt.rcParams['figure.dpi'] = output.get('dpi', 300)
        
        # 应用样式配置
        if 'style' in config:
            style = config['style']
            plt.rcParams['axes.grid'] = style.get('grid', True)
            plt.rcParams['grid.alpha'] = style.get('grid_alpha', 0.3)
            plt.rcParams['grid.linestyle'] = style.get('grid_linestyle', '--')
            plt.rcParams['axes.spines.top'] = style.get('spines_top', False)
            plt.rcParams['axes.spines.right'] = style.get('spines_right', False)
            plt.rcParams['axes.spines.bottom'] = style.get('spines_bottom', True)
            plt.rcParams['axes.spines.left'] = style.get('spines_left', True)
            plt.rcParams['xtick.direction'] = style.get('tick_direction', 'in')
            plt.rcParams['ytick.direction'] = style.get('tick_direction', 'in')
            plt.rcParams['xtick.major.size'] = style.get('tick_length', 3)
            plt.rcParams['ytick.major.size'] = style.get('tick_length', 3)
            plt.rcParams['xtick.major.width'] = style.get('tick_width', 0.8)
            plt.rcParams['ytick.major.width'] = style.get('tick_width', 0.8)
    
    def get_config(self) -> Dict[str, Any]:
        """
        获取当前合并后的配置
        
        Returns:
            Dict[str, Any]: 配置字典
        """
        return copy.deepcopy(self.merged_config)


# ====================
# 便捷函数
# ====================

def create_context(global_config: Union[str, Path, Dict[str, Any]],
                  local_config: Optional[Union[str, Path, Dict[str, Any]]] = None) -> PlotConfigContext:
    """
    创建配置上下文
    
    Args:
        global_config: 全局配置（路径或字典）
        local_config: 局部配置（路径或字典，可选）
        
    Returns:
        PlotConfigContext: 配置上下文实例
        
    使用示例:
        >>> ctx = create_context('global_config.json', 'local_config.json')
        >>> with ctx:
        ...     fig, ax = plt.subplots()
        ...     ax.plot([1, 2, 3], [1, 4, 9])
    """
    return PlotConfigContext(global_config, local_config)


def apply_publication_style(publication_name: str) -> PlotConfigContext:
    """
    应用出版物样式
    
    Args:
        publication_name: 出版物类型（'cea', 'ieee', 'nature', 'thesis', 'book'等）
        
    Returns:
        PlotConfigContext: 配置上下文实例
        
    使用示例:
        >>> with apply_publication_style('cea'):
        ...     fig, ax = plt.subplots()
        ...     ax.plot([1, 2, 3], [1, 4, 9])
    """
    from .configs.publication_config import get_publication_config
    config = get_publication_config(publication_name)
    return PlotConfigContext(config)


# 保持向后兼容的别名
apply_journal_style = apply_publication_style


@contextmanager
def temporary_config(config: Dict[str, Any]):
    """
    临时配置上下文管理器（简化版）
    
    Args:
        config: 临时配置字典
        
    Yields:
        None
        
    使用示例:
        >>> with temporary_config({'font': {'titlesize': 16}}):
        ...     fig, ax = plt.subplots()
        ...     ax.plot([1, 2, 3], [1, 4, 9])
    """
    original = plt.rcParams.copy()
    try:
        ctx = PlotConfigContext(config)
        ctx._apply_config(config)
        yield
    finally:
        plt.rcParams.update(original)
