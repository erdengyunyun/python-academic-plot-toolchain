# 示例代码说明

本目录包含《面向学术出版的Python图表工具链》的示例代码。

## 文件列表

| 文件名 | 说明 |
|-------|------|
| `paper_demo.py` | 中文版本示例代码（《计算机工程与应用》期刊模板） |
| `paper_demo_en.py` | 英文版本示例代码（IEEE/Nature模板） |
| `journal_examples.py` | 期刊样式基础示例 |

## 快速开始

### 1. 运行英文版本（推荐）

```bash
python examples/paper_demo_en.py
```

### 2. 运行中文版本

```bash
python examples/paper_demo.py
```

**注意**：中文版本需要系统安装方正书宋或宋体（SimSun）等中文字体。

## 输出目录结构

运行示例后会生成以下输出文件：

```
output/
├── example1_cea/              # CEA期刊示例
│   ├── png/cea_example.png
│   ├── jpg/cea_example.jpg
│   ├── pdf/cea_example.pdf
│   ├── svg/cea_example.svg
│   ├── eps/cea_example.eps
│   └── tiff/cea_example.tiff
├── example2_ieee/             # IEEE期刊示例
│   ├── png/
│   ├── jpg/
│   ├── pdf/
│   ├── svg/
│   ├── eps/
│   └── tiff/
└── example3_nature/           # Nature期刊示例
    ├── png/
    ├── jpg/
    ├── pdf/
    ├── svg/
    ├── eps/
    └── tiff/
```

**说明**：
- 每种示例生成六种格式：PNG、JPG、SVG、PDF、EPS、TIFF
- 文件按格式分子目录存放，便于管理和使用

## 核心API使用示例

### 基本使用流程

```python
from utils.plot_utils import PlotTool
import numpy as np

# 生成数据
x = np.linspace(0, 10, 100)
y = np.sin(x)

# 使用CEA期刊模板生成图表
with PlotTool('cea') as tool:
    tool.plot(x, y, label='sin(x)')
    tool.set_labels('时间/s', '振幅/m', '正弦函数')
    tool.legend()
    tool.grid()
    tool.save('output/figure')  # 自动保存六种格式
```

### 多子图示例

```python
with PlotTool('cea') as tool:
    # 创建2×2子图，8cm宽适合双栏
    fig, axes = tool.subplots(nrows=2, ncols=2, size='quarter')
    
    # 子图1
    axes[0, 0].plot(x, y1)
    axes[0, 0].set_title('(a) 子图1')
    
    # 子图2
    axes[0, 1].plot(x, y2)
    axes[0, 1].set_title('(b) 子图2')
    
    # 更多子图...
    
    plt.tight_layout()
    tool.save('output/multiplot')
```

### 配置文件驱动

```python
# 使用自定义配置文件
with PlotTool(config_file='custom_config.yaml') as tool:
    tool.plot(x, y)
    tool.save('output/custom')
```

## 支持的期刊模板

| 代码 | 期刊/场景 | 中文字体 | 英文字体 | 图中字号 |
|------|----------|---------|---------|---------|
| `cea` | 《计算机工程与应用》 | 6号方正书宋 | Times New Roman | 7.5pt |
| `ieee` | IEEE Transactions | 黑体 | Arial/Helvetica | 8pt |
| `nature` | Nature/Science | 黑体 | Arial/Helvetica | 8pt |
| `thesis` | 学位论文 | 黑体 | Times New Roman | 10pt |
| `book` | 教材书籍 | 宋体 | Times New Roman | 9pt |

## 标目格式要求

根据《计算机工程与应用》期刊要求，坐标轴标目格式必须为"物理量/单位"：

```python
# ✅ 正确
axes.set_xlabel('时间/s')
axes.set_ylabel('振幅/m')

# ❌ 错误
axes.set_xlabel('时间 (s)')
axes.set_ylabel('振幅(m)')
```

## 注意事项

1. **字体问题**：中文示例需要系统安装中文字体（方正书宋、SimSun等）
2. **依赖安装**：确保已安装所有依赖 `pip install -r requirements.txt`
3. **输出目录**：示例会自动创建 `output/` 目录并按格式分子目录存放文件
4. **PDF编码**：中文PDF保存可能存在编码问题，如失败可忽略，优先使用其他格式

## 格式说明

| 格式 | 类型 | 特点 | 适用场景 |
|------|------|------|---------|
| PNG | 位图 | 无损压缩 | 网页展示，PPT插入 |
| JPG | 位图 | 文件小 | 邮件传输，在线预览 |
| SVG | 矢量 | 可编辑 | 后期修改，网页矢量 |
| PDF | 矢量 | 投稿首选 | 期刊投稿，论文插入 |
| EPS | 矢量 | LaTeX首选 | LaTeX文档，印刷出版 |
| TIFF | 位图 | 高质量 | 高质量印刷，存档 |
