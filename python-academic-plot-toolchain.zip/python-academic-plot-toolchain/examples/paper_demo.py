"""
论文完整示例代码

本文件包含论文《面向学术出版的Python图表工具链构建与案例生成》中
所有案例的完整实现代码，可直接运行生成符合期刊规范的图表。
"""

import numpy as np
import matplotlib.pyplot as plt
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.plot_utils import (
    # 期刊样式
    setup_journal_style,
    get_figure_size,
    get_journal_config,
    list_supported_journals,
    get_journal_info,
    
    # 配置管理
    ConfigManager,
    PlotConfigContext,
    create_context,
    temporary_config,
    
    # 输出管理
    save_figure,
    save_multiformat,
    check_compliance,
    OutputManager,
    ComplianceReport,
    
    # 原有功能
    create_figure,
    create_subplots,
    save_figure_smart,
    save_figure_multiformat,
    calculate_optimal_layout,
    create_dynamic_grid,
)

from utils.plot_utils.configs.journal_config import (
    CEA_CONFIG,
    IEEE_CONFIG,
    NATURE_CONFIG
)


# ====================
# 示例1: 基本使用 - API使用示例（对应论文5.1节）
# ====================
def example_1_basic_api():
    """
    示例1: API使用示例
    
    展示生成一幅包含正弦、余弦曲线的出版级图表的完整流程。
    对应论文第5.1节。
    """
    print("\n" + "=" * 70)
    print("示例1: API使用示例 - 计算机工程与应用期刊样式")
    print("=" * 70)
    
    # 1. 应用期刊标准模板
    with setup_journal_style('cea'):
        # 2. 创建画布（自动应用预设布局）
        fig, ax = plt.subplots(figsize=(3.15, 2.36), dpi=300)
        
        # 3. 绘制数据
        x = np.linspace(0, 10, 100)
        ax.plot(x, np.sin(x), label='正弦曲线', linewidth=1.0)
        ax.plot(x, np.cos(x), label='余弦曲线', linestyle='--', linewidth=1.0)
        
        # 4. 添加图例和标签（样式自动统一）
        ax.legend(loc='best', frameon=True, framealpha=0.8)
        ax.set_xlabel('时间 (s)')
        ax.set_ylabel('振幅')
        ax.set_title('正弦和余弦函数')
        ax.grid(True, alpha=0.3, linestyle='--')
        
        # 5. 合规性检查
        print("\n合规性检查:")
        report = check_compliance(fig, CEA_CONFIG)
        print(report)
        
        # 6. 一键输出多格式（PDF/SVG/PNG）
        output_dir = "output/example1"
        os.makedirs(output_dir, exist_ok=True)
        
        paths = save_multiformat(
            fig,
            f"{output_dir}/trigonometric",
            formats=['png', 'svg', 'pdf', 'eps'],
            dpi=300
        )
        
        print(f"\n已保存文件:")
        for path in paths:
            print(f"  - {path}")
        
        plt.close(fig)
    
    print("\n示例1完成！\n")


# ====================
# 示例2: 多子图组合（对应论文5.2节）
# ====================
def example_2_multi_subplot():
    """
    示例2: 多子图组合的协同生成与样式统一
    
    生成包含四个子图的复合图，分别以折线图、柱状图、散点图和箱线图
    展示同一数据集的不同统计视角。
    对应论文第3.2节和5.2节。
    """
    print("\n" + "=" * 70)
    print("示例2: 多子图组合 - Nature/Science期刊样式")
    print("=" * 70)
    
    with setup_journal_style('nature'):
        # 获取Nature单栏尺寸并调整高度
        figsize = get_figure_size('nature', 'single')
        figsize = (figsize[0], figsize[0] * 1.2)
        
        # 创建2x2子图网格
        fig, axes = plt.subplots(2, 2, figsize=figsize, dpi=300)
        fig.patch.set_facecolor('white')
        
        # 生成数据
        np.random.seed(42)
        x = np.linspace(0, 10, 100)
        
        # 子图1: 折线图
        axes[0, 0].plot(x, np.sin(x), label='sin(x)', 
                       linewidth=1.2, color='#0072B2')
        axes[0, 0].plot(x, np.cos(x), label='cos(x)', 
                       linewidth=1.2, linestyle='--', color='#D55E00')
        axes[0, 0].set_xlabel('X')
        axes[0, 0].set_ylabel('Y')
        axes[0, 0].set_title('(a) 三角函数')
        axes[0, 0].legend(fontsize=6)
        axes[0, 0].grid(True, alpha=0.3)
        
        # 子图2: 散点图
        x_scatter = np.random.randn(50)
        y_scatter = np.random.randn(50)
        axes[0, 1].scatter(x_scatter, y_scatter, 
                          alpha=0.6, s=20, color='#009E73')
        axes[0, 1].set_xlabel('X')
        axes[0, 1].set_ylabel('Y')
        axes[0, 1].set_title('(b) 散点分布')
        axes[0, 1].grid(True, alpha=0.3)
        
        # 子图3: 直方图
        data = np.random.normal(0, 1, 1000)
        axes[1, 0].hist(data, bins=20, alpha=0.7, 
                       color='#0072B2', edgecolor='black')
        axes[1, 0].set_xlabel('值')
        axes[1, 0].set_ylabel('频数')
        axes[1, 0].set_title('(c) 数据分布')
        axes[1, 0].grid(True, axis='y', alpha=0.3)
        
        # 子图4: 箱线图
        data_box = [np.random.normal(0, 1, 100) 
                    for _ in range(3)]
        bp = axes[1, 1].boxplot(data_box, patch_artist=True)
        colors = ['#0072B2', '#D55E00', '#009E73']
        for patch, color in zip(bp['boxes'], colors):
            patch.set_facecolor(color)
        axes[1, 1].set_xlabel('类别')
        axes[1, 1].set_ylabel('值')
        axes[1, 1].set_title('(d) 箱线图')
        axes[1, 1].grid(True, axis='y', alpha=0.3)
        
        plt.tight_layout()
        
        # 保存
        output_dir = "output/example2"
        os.makedirs(output_dir, exist_ok=True)
        
        paths = save_multiformat(
            fig,
            f"{output_dir}/multi_panel",
            formats=['png', 'svg', 'pdf', 'eps'],
            dpi=300
        )
        
        print(f"\n已保存文件:")
        for path in paths:
            print(f"  - {path}")
        
        plt.close(fig)
    
    print("\n示例2完成！\n")


# ====================
# 示例3: IEEE期刊样式 - 性能对比图
# ====================
def example_3_ieee_performance():
    """
    示例3: IEEE Transactions期刊样式 - 性能对比图
    
    展示不同方法的性能对比，使用柱状图。
    对应论文第3.2节。
    """
    print("\n" + "=" * 70)
    print("示例3: IEEE Transactions期刊样式 - 性能对比")
    print("=" * 70)
    
    with setup_journal_style('ieee'):
        # IEEE双栏图表尺寸
        figsize = get_figure_size('ieee', 'double')
        
        fig, ax = plt.subplots(figsize=figsize, dpi=300)
        
        # 生成性能对比数据
        methods = ['Method A', 'Method B', 'Method C', 'Method D']
        accuracy = [0.85, 0.88, 0.92, 0.95]
        std_dev = [0.02, 0.015, 0.018, 0.012]
        
        # 绘制柱状图（带误差棒）
        bars = ax.bar(methods, accuracy, 
                     yerr=std_dev, 
                     color='#0066CC', 
                     alpha=0.8,
                     capsize=3,
                     error_kw={'linewidth': 1.0, 'capthick': 1.0})
        
        # 添加数值标签
        for bar, acc, std in zip(bars, accuracy, std_dev):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + std + 0.01,
                   f'{acc:.2f}',
                   ha='center', va='bottom', fontsize=7)
        
        ax.set_xlabel('方法', fontweight='normal')
        ax.set_ylabel('准确率', fontweight='normal')
        ax.set_title('不同方法的性能对比', fontweight='bold')
        ax.set_ylim(0.8, 1.0)
        ax.grid(True, axis='y', alpha=0.3, linestyle=':')
        
        # 添加显著性标记
        ax.text(0.5, 0.98, '* p < 0.05', 
               transform=ax.transAxes, 
               fontsize=7, 
               verticalalignment='top')
        
        # 保存
        output_dir = "output/example3"
        os.makedirs(output_dir, exist_ok=True)
        
        paths = save_multiformat(
            fig,
            f"{output_dir}/ieee_performance",
            formats=['png', 'svg', 'pdf', 'eps'],
            dpi=300
        )
        
        print(f"\n已保存文件:")
        for path in paths:
            print(f"  - {path}")
        
        plt.close(fig)
    
    print("\n示例3完成！\n")


# ====================
# 示例4: 配置管理功能演示
# ====================
def example_4_config_management():
    """
    示例4: 配置管理功能演示
    
    展示YAML/JSON配置加载、上下文管理等功能。
    对应论文第2.3.1节和第4.1节。
    """
    print("\n" + "=" * 70)
    print("示例4: 配置管理功能演示")
    print("=" * 70)
    
    # 1. 列出支持的期刊
    print("\n1. 支持的期刊列表:")
    journals = list_supported_journals()
    for journal in journals:
        info = get_journal_info(journal)
        print(f"   - {journal}: {info['name']}")
        print(f"     {info['description']}")
    
    # 2. 获取期刊配置
    print("\n2. 计算机工程与应用期刊配置:")
    config = get_journal_config('cea')
    print(f"   字体: {config['font']['family']}")
    print(f"   字号: 标题{config['font']['titlesize']}pt, "
          f"标签{config['font']['labelsize']}pt")
    print(f"   单栏尺寸: {config['figure_size']['single']} inches")
    print(f"   推荐格式: {', '.join(config['output']['formats'])}")
    
    # 3. 使用ConfigManager加载和保存配置
    print("\n3. 配置管理器演示:")
    manager = ConfigManager()
    
    # 保存配置到JSON
    output_dir = "output/example4"
    os.makedirs(output_dir, exist_ok=True)
    
    config_path = f"{output_dir}/custom_config.json"
    custom_config = {
        'font': {
            'family': ['Arial', 'sans-serif'],
            'titlesize': 12,
            'labelsize': 10,
            'ticksize': 9
        },
        'figure_size': {
            'single': (4.0, 3.0),
            'double': (8.0, 3.0)
        },
        'output': {
            'dpi': 300,
            'formats': ['pdf', 'png']
        }
    }
    
    manager.save_config(custom_config, config_path, format='json')
    print(f"   配置已保存到: {config_path}")
    
    # 加载配置
    loaded_config = manager.load_config(config_path)
    print(f"   配置加载成功: {loaded_config['font']['family']}")
    
    # 4. 使用PlotConfigContext
    print("\n4. 上下文管理器演示:")
    
    with PlotConfigContext(custom_config):
        fig, ax = plt.subplots(figsize=(4.0, 3.0), dpi=300)
        
        x = np.linspace(0, 10, 100)
        ax.plot(x, np.sin(x), label='sin(x)')
        ax.set_xlabel('X轴')
        ax.set_ylabel('Y轴')
        ax.set_title('自定义配置示例')
        ax.legend()
        
        save_path = f"{output_dir}/custom_config_demo"
        paths = save_multiformat(fig, save_path, formats=['png', 'svg', 'pdf', 'eps'], dpi=300)
        
        print(f"   图表已保存: {paths[0]}")
        plt.close(fig)
    
    print("\n示例4完成！\n")


# ====================
# 示例5: 合规性检查详细演示
# ====================
def example_5_compliance_check():
    """
    示例5: 合规性检查详细演示
    
    展示如何检查图表是否符合期刊规范。
    对应论文第4.3节。
    """
    print("\n" + "=" * 70)
    print("示例5: 合规性检查详细演示")
    print("=" * 70)
    
    # 创建一个符合规范的图表
    print("\n1. 创建符合规范的图表:")
    with setup_journal_style('cea'):
        fig, ax = plt.subplots(figsize=(3.15, 2.36), dpi=300)
        
        x = np.linspace(0, 10, 100)
        ax.plot(x, np.sin(x))
        ax.set_xlabel('时间 (s)')
        ax.set_ylabel('振幅')
        ax.set_title('正弦函数')
        
        # 合规性检查
        report = check_compliance(fig, CEA_CONFIG, strict=False)
        print(f"   检查结果: {'通过' if report.passed else '未通过'}")
        print(f"   检查项数: {len(report.checks)}")
        if report.warnings:
            print(f"   警告数: {len(report.warnings)}")
        
        plt.close(fig)
    
    # 创建一个不符合规范的图表（故意设置低DPI）
    print("\n2. 创建不符合规范的图表（低DPI）:")
    fig, ax = plt.subplots(figsize=(3.15, 2.36), dpi=72)  # 低DPI
    
    x = np.linspace(0, 10, 100)
    ax.plot(x, np.sin(x))
    ax.set_xlabel('时间 (s)')
    ax.set_ylabel('振幅')
    
    # 严格模式检查
    report = check_compliance(fig, CEA_CONFIG, strict=True)
    print(f"   检查结果: {'通过' if report.passed else '未通过'}")
    if not report.passed:
        print(f"   错误: {report.errors}")
    
    plt.close(fig)
    
    print("\n示例5完成！\n")


# ====================
# 示例6: 动态布局计算
# ====================
def example_6_dynamic_layout():
    """
    示例6: 动态布局计算
    
    展示自动计算最优子图布局的功能。
    对应论文第2.3.2节。
    """
    print("\n" + "=" * 70)
    print("示例6: 动态布局计算")
    print("=" * 70)
    
    # 测试不同数量的子图
    for n_plots in [3, 5, 7]:
        rows, cols = calculate_optimal_layout(n_plots)
        print(f"\n{n_plots}个子图 -> {rows}行 × {cols}列")
        
        # 创建动态网格
        fig, axes = create_dynamic_grid(
            n_plots, 
            figsize=(6, 4),
            dpi=300,
            add_labels=True
        )
        
        # 在每个子图中绘制简单图形
        for i, ax in enumerate(axes.flat[:n_plots]):
            x = np.linspace(0, 10, 50)
            ax.plot(x, np.sin(x + i))
            ax.set_title(f'子图 {i+1}')
        
        # 保存
        output_dir = "output/example6"
        os.makedirs(output_dir, exist_ok=True)
        
        save_path = f"{output_dir}/layout_{n_plots}plots"
        paths = save_multiformat(fig, save_path, formats=['png', 'svg', 'pdf', 'eps'], dpi=300)
        
        print(f"   已保存: {paths[0]}")
        plt.close(fig)
    
    print("\n示例6完成！\n")


# ====================
# 主函数
# ====================
def main():
    """主函数：运行所有示例"""
    print("\n")
    print("*" * 70)
    print("论文《面向学术出版的Python图表工具链构建与案例生成》")
    print("完整示例代码")
    print("*" * 70)
    print("\n")
    
    # 创建输出目录
    os.makedirs("output", exist_ok=True)
    
    # 运行所有示例
    try:
        example_1_basic_api()          # 示例1: API使用示例
        example_2_multi_subplot()      # 示例2: 多子图组合
        example_3_ieee_performance()   # 示例3: IEEE性能对比
        example_4_config_management()  # 示例4: 配置管理
        example_5_compliance_check()   # 示例5: 合规性检查
        example_6_dynamic_layout()     # 示例6: 动态布局
        
        print("*" * 70)
        print("所有示例运行完成！")
        print("输出文件保存在 output/ 目录下")
        print("*" * 70)
        
    except Exception as e:
        print(f"\n运行示例时出错: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
