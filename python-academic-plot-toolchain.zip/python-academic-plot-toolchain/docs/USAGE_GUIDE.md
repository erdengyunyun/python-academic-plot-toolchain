# 学术图表工具链使用指南

## 概述

本工具链面向学术出版场景，提供从数据到出版级图表的全流程自动化生成能力。支持中文期刊、英文期刊、学术论文、教材书籍等多种学术出版场景的图表规范，通过配置驱动架构和上下文隔离机制，实现图表生成的标准化与自动化。

## 项目结构

```
academic_plots/
├── docs/                       # 文档目录
│   ├── USAGE_GUIDE.md         # 本使用指南
│   ├── paper_v2.md            # 论文完整版
│   └── figures/               # 论文插图
├── examples/                   # 示例代码
│   ├── paper_demo.py          # 中文示例（论文案例）
│   ├── paper_demo_en.py       # 英文示例（推荐）
│   ├── journal_examples.py    # 期刊样式示例
│   └── EXAMPLES_README.md     # 示例说明
├── utils/                      # 核心工具包
│   └── plot_utils/            # 图表工具链
│       ├── __init__.py        # 包入口
│       ├── plot_tool.py       # PlotTool简化API
│       ├── config_manager.py  # 配置管理器
│       ├── font_manager.py    # 字体管理器
│       ├── output_manager.py  # 输出管理器
│       └── configs/           # 配置目录
│           ├── publication_config.py  # 出版物配置
│           └── style_config.py        # 样式配置
├── output/                     # 输出目录
│   └── [示例名称]/            # 按示例分子目录
│       ├── png/               # PNG格式（位图，通用）
│       ├── jpg/               # JPG格式（位图，小文件）
│       ├── pdf/               # PDF格式（矢量，投稿首选）
│       ├── svg/               # SVG格式（矢量，可编辑）
│       ├── eps/               # EPS格式（矢量，LaTeX首选）
│       └── tiff/              # TIFF格式（位图，高质量）
├── README.md                   # 项目说明
└── requirements.txt            # 依赖列表
```

### 输出目录结构

工具链采用**按示例和格式双重分类**的目录结构：

```
output/
├── example1_cea/              # CEA期刊示例
│   ├── png/figure.png         # PNG位图
│   ├── jpg/figure.jpg         # JPG位图
│   ├── pdf/figure.pdf         # PDF矢量图
│   ├── svg/figure.svg         # SVG矢量图
│   ├── eps/figure.eps         # EPS矢量图
│   └── tiff/figure.tiff       # TIFF高质量位图
├── example2_ieee/             # IEEE期刊示例
│   ├── png/
│   ├── jpg/
│   ├── pdf/
│   ├── svg/
│   ├── eps/
│   └── tiff/
└── example4_iris/             # 鸢尾花案例分析
    ├── png/
    ├── jpg/
    ├── pdf/
    ├── svg/
    ├── eps/
    └── tiff/
```

**优点**：
- 不同示例的文件分开存放，便于管理
- 同一张图的不同格式放在一起，便于选择使用
- 符合学术出版文件组织的最佳实践

## 核心特性

- **场景模板化**：内置多种学术出版场景模板（中文期刊、英文期刊、国际顶刊等），一键应用
- **简化API**：PlotTool类提供方法链式调用，8行代码完成出版级图表生成
- **配置驱动**：支持YAML/JSON配置文件，实现样式全局统一管控
- **上下文隔离**：配置原子化切换，避免跨图表配置污染
- **多格式输出**：默认保存六种格式（PNG、JPG、SVG、PDF、EPS、TIFF），满足不同投稿要求
- **合规性校验**：自动检查图表是否符合出版规范

## 环境配置

### 系统要求

- **操作系统**: Windows 10/11, macOS 10.14+, Ubuntu 18.04+
- **Python版本**: Python 3.8 或更高版本
- **内存**: 建议4GB以上
- **磁盘空间**: 至少500MB可用空间

### 安装步骤

#### 1. 克隆或下载项目

```bash
# 使用git克隆（推荐）
git clone https://github.com/yourusername/academic_plots.git
cd academic_plots

# 或直接下载ZIP文件并解压
cd academic_plots
```

#### 2. 创建虚拟环境（推荐）

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

#### 3. 安装依赖

```bash
# 安装所有必需依赖
pip install -r requirements.txt

# 或仅安装核心依赖（最小安装）
pip install matplotlib numpy pillow pyyaml scikit-learn
```

**依赖说明：**

| 依赖包 | 版本要求 | 用途 | 必需性 |
|--------|---------|------|--------|
| matplotlib | >=3.5.0 | 图表绘制核心库 | 必需 |
| numpy | >=1.21.0 | 数值计算 | 必需 |
| pillow | >=8.0.0 | 图像处理 | 必需 |
| pyyaml | >=6.0 | YAML配置文件支持 | 必需 |
| scikit-learn | >=1.0.0 | 机器学习数据集（示例使用） | 必需 |

#### 4. 验证安装

```bash
# 运行简单测试
python -c "from utils.plot_utils import PlotTool; print('✓ 安装成功')"

# 运行示例代码
python examples/paper_demo_en.py
```

### 字体配置

#### Windows系统

Windows系统通常已预装所需中文字体（如SimHei、SimSun），无需额外配置。

#### macOS系统

macOS系统需要安装中文字体：

```bash
# 检查已安装字体
python -c "from utils.plot_utils.font_manager import FontManager; fm = FontManager(); print(fm.get_available_fonts())"

# 如缺少中文字体，可安装：
# 1. 下载中文字体（如思源黑体）
# 2. 双击字体文件安装
# 3. 重启终端
```

#### Linux系统

Ubuntu/Debian系统：

```bash
# 安装中文字体
sudo apt-get update
sudo apt-get install fonts-wqy-zenhei fonts-wqy-microhei

# 刷新字体缓存
sudo fc-cache -fv
```

CentOS/RHEL系统：

```bash
# 安装中文字体
sudo yum install wqy-zenhei-fonts wqy-microhei-fonts
```

### 常见问题

#### 1. pip安装速度慢

```bash
# 使用国内镜像源
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

# 或设置默认镜像
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
```

#### 2. 安装失败：编译错误

某些依赖可能需要编译工具：

```bash
# Windows: 安装Microsoft C++ Build Tools
# 下载地址: https://visualstudio.microsoft.com/visual-cpp-build-tools/

# macOS: 安装Xcode命令行工具
xcode-select --install

# Linux: 安装编译工具
sudo apt-get install python3-dev build-essential  # Ubuntu/Debian
sudo yum install python3-devel gcc                 # CentOS/RHEL
```

#### 3. 字体显示为方框

```python
# 检查可用字体
from utils.plot_utils.font_manager import FontManager
fm = FontManager()
available_fonts = fm.get_available_fonts()
print(f"系统共有 {len(available_fonts)} 个字体")

# 检查中文字体
chinese_fonts = [f for f in available_fonts if 'Song' in f or 'Hei' in f or 'YaHei' in f]
print(f"中文字体: {chinese_fonts}")
```

#### 4. 权限错误（Linux/macOS）

```bash
# 如果安装到系统Python遇到权限问题，使用--user参数
pip install --user -r requirements.txt

# 或确保虚拟环境已激活
which python  # 检查当前Python路径
```

## 快速开始

### 基本使用（推荐）

使用 `PlotTool` 简化API，仅需8行代码：

```python
from utils.plot_utils import PlotTool
import numpy as np

# 生成数据
x = np.linspace(0, 10, 100)
y1 = np.sin(x)
y2 = np.cos(x)

# 使用简化API生成图表
with PlotTool('cea') as tool:
    tool.plot(x, y1, label='正弦曲线')
    tool.plot(x, y2, label='余弦曲线', linestyle='--')
    tool.set_labels('时间/s', '振幅/m', '正弦和余弦函数')
    tool.legend()
    tool.grid()
    tool.save('output/figure')
```

**代码说明：**
- `PlotTool('cea')`：选择《计算机工程与应用》期刊模板，自动配置中文字体、字号、尺寸
- `plot()`：绘制折线图，默认线宽1.0，自动应用场景配色
- `set_labels()`：一键设置X轴标签、Y轴标签、标题，标签格式为"物理量/单位"
- `save()`：自动保存JPG、SVG、PDF、EPS四种格式

**重要：标目格式要求**

根据《计算机工程与应用》期刊要求，坐标轴标目格式必须为"物理量/单位"：

```python
# ✅ 正确：使用"/"分隔物理量和单位
axes.set_xlabel('时间/s')
axes.set_ylabel('振幅/m')

# ❌ 错误：使用空格或括号
axes.set_xlabel('时间 (s)')  # 不符合规范
axes.set_ylabel('振幅(m)')   # 不符合规范
```

### 一行代码快速绘图

对于简单图表，可使用 `quick_plot` 静态方法：

```python
from utils.plot_utils import PlotTool
import numpy as np

x = np.linspace(0, 10, 100)
y = np.sin(x) * np.exp(-x/10)

# 一行代码完成所有操作
PlotTool.quick_plot(
    x, y,
    publication='cea',
    xlabel='时间/s',
    ylabel='振幅/m',
    title='阻尼正弦波',
    label='sin(x)·exp(-x/10)',
    output='output/quick_example'
)
```

## 支持的学术出版场景

| 场景代码 | 应用场景 | 中文字体 | 英文字体 | 图中字号 | 图题字号 |
|---------|---------|---------|---------|---------|---------|
| `cea` | 《计算机工程与应用》 | 6号方正书宋 | Times New Roman | 7.5pt | 9pt |
| `ieee` | IEEE Transactions | 黑体 | Arial/Helvetica | 8pt | 9pt |
| `nature` | Nature/Science | 黑体 | Arial/Helvetica | 8pt | 10pt |
| `thesis` | 学位论文 | 黑体 | Times New Roman | 10pt | 12pt |
| `book` | 教材书籍 | 宋体 | Times New Roman | 9pt | 10pt |

### CEA期刊特殊要求

《计算机工程与应用》期刊有以下特殊要求：

1. **字体**：图中中文6号方正书宋，英文Times New Roman
2. **标目格式**："物理量/单位"（如"时间/s"）
3. **刻度线**：朝内
4. **图例**：清晰不压图，使用不同线型区分
5. **线条**：粗细统一

```python
with PlotTool('cea') as tool:
    fig, ax = tool.subplots(size='quarter')  # 8cm宽，适合双栏
    
    # 绘制曲线，使用不同线型区分
    ax.plot(x, y1, label='方法A', linestyle='-')
    ax.plot(x, y2, label='方法B', linestyle='--')
    ax.plot(x, y3, label='方法C', linestyle='-.')
    
    # 标目格式：物理量/单位
    ax.set_xlabel('时间/s')
    ax.set_ylabel('准确率/%')
    ax.set_title('方法性能对比')
    
    # 图例自动选择最佳位置
    ax.legend(loc='best', frameon=True)
    
    tool.save('output/cea_figure')
```

## API参考

### PlotTool 简化API

#### `PlotTool(journal='default', config_file=None)`

简化API类，提供一键式图表生成。

**参数：**
- `journal` (str): 场景代码，可选 `'cea'`, `'ieee'`, `'nature'`, `'thesis'`, `'book'`
- `config_file` (str): 自定义配置文件路径（YAML/JSON），可选

**使用示例：**
```python
with PlotTool('cea') as tool:
    tool.plot(x, y, label='数据')
    tool.set_labels('X轴', 'Y轴', '标题')
    tool.legend()
    tool.save('output/figure')
```

#### `plot(x, y=None, label=None, **kwargs)`

绘制折线图。

**参数：**
- `x` (array): X轴数据
- `y` (array): Y轴数据，可选
- `label` (str): 图例标签
- `**kwargs`: 其他matplotlib参数

#### `scatter(x, y, **kwargs)`

绘制散点图。

**参数：**
- `x` (array): X轴数据
- `y` (array): Y轴数据
- `**kwargs`: 其他matplotlib参数

#### `bar(x, y, **kwargs)`

绘制柱状图。

**参数：**
- `x` (array): X轴数据
- `y` (array): Y轴数据
- `**kwargs`: 其他matplotlib参数

#### `set_labels(xlabel=None, ylabel=None, title=None)`

一键设置坐标轴标签和标题。

**参数：**
- `xlabel` (str): X轴标签，格式为"物理量/单位"
- `ylabel` (str): Y轴标签，格式为"物理量/单位"
- `title` (str): 图表标题

#### `legend(**kwargs)`

显示图例。

#### `grid(**kwargs)`

显示网格。

#### `save(filepath, formats=None)`

保存图表到多种格式。

**参数：**
- `filepath` (str): 文件路径（不含扩展名）
- `formats` (list): 格式列表，默认`['png', 'jpg', 'svg', 'pdf', 'eps', 'tiff']`（六种学术出版常用格式）

**格式说明：**

| 格式 | 类型 | 特点 | 适用场景 |
|------|------|------|---------|
| PNG | 位图 | 无损压缩，透明背景 | 网页展示，PPT插入 |
| JPG | 位图 | 有损压缩，文件小 | 邮件传输，在线预览 |
| SVG | 矢量 | 可编辑，无限缩放 | 后期修改，网页矢量 |
| PDF | 矢量 | 投稿首选，跨平台 | 期刊投稿，论文插入 |
| EPS | 矢量 | LaTeX首选，印刷级 | LaTeX文档，印刷出版 |
| TIFF | 位图 | 高质量，无损 | 高质量印刷，存档 |

#### `subplots(nrows=1, ncols=1, size='single', **kwargs)`

创建子图。

**参数：**
- `nrows` (int): 行数，默认1
- `ncols` (int): 列数，默认1
- `size` (str): 尺寸类型：
  - `'quarter'`: 8cm × 10cm（适合双栏2×2子图）
  - `'eighth'`: 8cm × 5cm（适合双栏1×2子图）
  - `'single'`: 8cm × 6cm（单栏）
  - `'double'`: 17cm × 7cm（双栏）

**返回：**
- `(fig, axes)`: 图表对象和坐标轴对象

#### `PlotTool.quick_plot(x, y, publication='default', xlabel='', ylabel='', title='', label='', output='output')`

静态方法，一行代码完成绘图和保存。

### 配置管理

#### 配置文件驱动

支持YAML/JSON格式的配置文件：

```yaml
# custom_config.yaml
font:
  family: ['Arial', 'sans-serif']
  titlesize: 12
  labelsize: 10

figure_size:
  single: [4, 3]

color:
  cycle: ['#0072B2', '#D55E00', '#009E73']
```

使用配置文件：
```python
with PlotTool(config_file='custom_config.yaml') as tool:
    tool.plot(x, y)
    tool.save('output/custom')
```

## 完整示例

### 鸢尾花分类分析（论文案例）

```python
from sklearn.datasets import load_iris
from utils.plot_utils import PlotTool
import matplotlib.pyplot as plt

# 加载数据
iris = load_iris()
X, y = iris.data, iris.target
target_names = iris.target_names

# 使用CEA模板
with PlotTool('cea') as tool:
    # 创建2×2子图，8cm宽适合双栏
    fig, axes = tool.subplots(nrows=2, ncols=2, size='quarter')
    
    # 色盲友好配色
    colors = ['#0072B2', '#D55E00', '#009E73']
    
    # 子图1: 花萼特征散点图
    for i, (target, color) in enumerate(zip(target_names, colors)):
        mask = y == i
        axes[0, 0].scatter(X[mask, 0], X[mask, 1], c=color, label=target, 
                          alpha=0.7, s=20, edgecolors='black', linewidth=0.5)
    axes[0, 0].set_xlabel('花萼长度/cm')
    axes[0, 0].set_ylabel('花萼宽度/cm')
    axes[0, 0].set_title('(a) 花萼特征分布')
    axes[0, 0].legend(loc='upper right', frameon=True)
    axes[0, 0].grid(True, alpha=0.3)
    
    # 子图2: 花瓣特征散点图
    for i, (target, color) in enumerate(zip(target_names, colors)):
        mask = y == i
        axes[0, 1].scatter(X[mask, 2], X[mask, 3], c=color, label=target,
                          alpha=0.7, s=20, edgecolors='black', linewidth=0.5)
    axes[0, 1].set_xlabel('花瓣长度/cm')
    axes[0, 1].set_ylabel('花瓣宽度/cm')
    axes[0, 1].set_title('(b) 花瓣特征分布')
    axes[0, 1].legend(loc='upper left', frameon=True)
    axes[0, 1].grid(True, alpha=0.3)
    
    # 子图3: 花瓣长度分布直方图
    for i, (target, color) in enumerate(zip(target_names, colors)):
        mask = y == i
        axes[1, 0].hist(X[mask, 2], bins=12, alpha=0.6, color=color, 
                       label=target, edgecolor='black', linewidth=0.5)
    axes[1, 0].set_xlabel('花瓣长度/cm')
    axes[1, 0].set_ylabel('频数')
    axes[1, 0].set_title('(c) 花瓣长度分布')
    axes[1, 0].legend(frameon=True)
    axes[1, 0].grid(True, axis='y', alpha=0.3)
    
    # 子图4: 箱线图
    data_for_box = [X[y==i, 2] for i in range(3)]
    bp = axes[1, 1].boxplot(data_for_box, tick_labels=target_names, patch_artist=True)
    for patch, color in zip(bp['boxes'], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
    axes[1, 1].set_xlabel('类别')
    axes[1, 1].set_ylabel('花瓣长度/cm')
    axes[1, 1].set_title('(d) 各类别花瓣长度统计')
    axes[1, 1].grid(True, axis='y', alpha=0.3)
    
    plt.tight_layout(pad=0.3)
    tool.save('output/iris_analysis')
```

## 运行示例

```bash
# 中文示例（论文案例）
python examples/paper_demo.py

# 英文示例（推荐）
python examples/paper_demo_en.py

# 期刊样式示例
python examples/journal_examples.py
```

## 注意事项

1. **字体安装**：确保系统已安装所需字体（方正书宋、Times New Roman、黑体等）
2. **标目格式**：坐标轴标签必须使用"物理量/单位"格式
3. **尺寸选择**：双栏图表使用`size='quarter'`（8cm宽）
4. **图例位置**：使用`loc='best'`自动选择最佳位置，避免压图
5. **矢量图**：学术投稿优先使用PDF或EPS格式
6. **配置隔离**：使用`with PlotTool(...) as tool:`确保配置不影响其他图表

## 故障排除

### 中文显示为方框

如果中文显示为方框，可能是字体未正确安装：

```python
# 检查可用字体
from utils.plot_utils.font_manager import FontManager
fm = FontManager()
print(fm.get_available_fonts())
```

### PDF保存失败

中文PDF保存可能存在编码问题，优先使用JPG、SVG、EPS格式。

## 版本信息

**v2.0.0** - 面向学术出版的Python图表工具链
- 新增PlotTool简化API
- 新增学术出版场景模板系统
- 新增配置管理模块
- 新增上下文管理器
- 新增多格式输出
