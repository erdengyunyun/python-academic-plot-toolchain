"""
简化API - PlotTool类

提供一键式学术图表生成工具，简化使用流程。

使用示例:
    # 方式1: 极简模式
    from utils.plot_utils import PlotTool
    
    with PlotTool('cea') as tool:
        tool.plot(x, y, label='数据')
        tool.set_labels('时间(s)', '振幅', '正弦函数')
        tool.save('output/figure')
    
    # 方式2: 兼容matplotlib
    with PlotTool('ieee') as tool:
        fig, ax = tool.subplots()
        ax.plot(x, y)
        tool.save('output/figure')
"""

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import numpy as np
from pathlib import Path
from typing import Optional, List, Tuple, Union, Dict, Any, Callable
import yaml
import json

# 强制刷新字体管理器，确保系统字体被正确加载
# 方法1: 尝试清除缓存并重新加载
try:
    # 删除缓存文件（如果存在）
    import os
    import glob
    cache_dir = matplotlib.get_cachedir()
    for cache_file in glob.glob(os.path.join(cache_dir, "fontlist-*.json")):
        try:
            os.remove(cache_file)
        except:
            pass
    # 重新创建字体管理器
    fm.fontManager = fm.FontManager()
except:
    pass

from .configs.publication_config import get_publication_config, list_supported_publications
from .output_manager import OutputManager, check_compliance
from .font_manager import FontManager


class PlotTool:
    """
    学术图表工具类 - 简化API
    
    一键式生成符合学术出版物规范的图表，自动处理:
    - 出版物样式配置（期刊、学位论文、教材书籍等）
    - 字体设置
    - 图形尺寸
    - 多格式输出
    - 合规性检查
    """
    
    def __init__(self, 
                 publication: str = 'default',
                 config_file: Optional[str] = None,
                 auto_check: bool = True,
                 output_dir: str = '.'):
        """
        初始化PlotTool
        
        Args:
            publication: 出版物类型 ('cea', 'ieee', 'nature', 'thesis', 'book', 'default')
            config_file: 配置文件路径 (YAML或JSON)
            auto_check: 是否自动进行合规性检查
            output_dir: 默认输出目录
        """
        self.publication = publication
        self.auto_check = auto_check
        self.output_dir = Path(output_dir)
        
        # 加载配置
        if config_file:
            self.config = self._load_config_file(config_file)
        else:
            self.config = get_publication_config(publication)
        
        # 初始化输出管理器
        self.output_manager = OutputManager(
            default_dpi=self.config.get('output', {}).get('dpi', 300)
        )
        
        # 保存原始配置
        self._original_rcparams = None
        self.fig = None
        self.ax = None
        
    def _load_config_file(self, filepath: str) -> Dict[str, Any]:
        """加载配置文件"""
        filepath = Path(filepath)
        if not filepath.exists():
            raise FileNotFoundError(f"配置文件不存在: {filepath}")
        
        with open(filepath, 'r', encoding='utf-8') as f:
            if filepath.suffix in ['.yaml', '.yml']:
                return yaml.safe_load(f)
            elif filepath.suffix == '.json':
                return json.load(f)
            else:
                raise ValueError(f"不支持的配置文件格式: {filepath.suffix}")
    
    def __enter__(self):
        """进入上下文，应用配置"""
        self._original_rcparams = plt.rcParams.copy()
        self._apply_config()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出上下文，恢复配置"""
        if self._original_rcparams is not None:
            plt.rcParams.update(self._original_rcparams)
    
    def _apply_config(self):
        """应用出版物配置到Matplotlib，使用智能字体选择"""
        font_prefs = self.config.get('font', {})
        
        # 使用字体管理器获取实际可用的字体配置
        font = FontManager.get_font_config(font_prefs)
        
        # 字体配置 - 确保中文字体优先
        font_family = font.get('family', ['sans-serif'])
        plt.rcParams['font.family'] = font_family
        
        # 设置无衬线字体族（用于中文显示）
        # 使用过滤后的可用字体列表
        sans_serif = font.get('sans-serif', ['Arial', 'Helvetica'])
        plt.rcParams['font.sans-serif'] = sans_serif
        
        # 设置衬线字体族
        serif = font.get('serif', ['Times New Roman'])
        plt.rcParams['font.serif'] = serif
        
        # 设置等宽字体
        monospace = font.get('monospace', ['Consolas'])
        plt.rcParams['font.monospace'] = monospace
        
        # 字号配置
        plt.rcParams['axes.titlesize'] = font.get('titlesize', 10)
        plt.rcParams['axes.labelsize'] = font.get('labelsize', 9)
        plt.rcParams['xtick.labelsize'] = font.get('ticksize', 8)
        plt.rcParams['ytick.labelsize'] = font.get('ticksize', 8)
        plt.rcParams['legend.fontsize'] = font.get('legendsize', 8)
        
        # 字重
        plt.rcParams['axes.titleweight'] = font.get('titleweight', 'bold')
        plt.rcParams['axes.labelweight'] = font.get('labelweight', 'normal')
        
        # 数学文本字体
        plt.rcParams['mathtext.fontset'] = 'custom'
        plt.rcParams['mathtext.rm'] = 'Arial'
        plt.rcParams['mathtext.it'] = 'Arial:italic'
        plt.rcParams['mathtext.bf'] = 'Arial:bold'
        
        # 解决负号显示问题
        plt.rcParams['axes.unicode_minus'] = False
        
        # 线条样式
        line = self.config.get('line', {})
        plt.rcParams['lines.linewidth'] = line.get('linewidth', 1.0)
        plt.rcParams['axes.linewidth'] = line.get('border_linewidth', 0.8)
        plt.rcParams['grid.linewidth'] = line.get('grid_linewidth', 0.5)
        
        # 颜色配置
        color = self.config.get('color', {})
        if 'cycle' in color:
            from cycler import cycler
            plt.rcParams['axes.prop_cycle'] = cycler(color=color['cycle'])
        
        # 样式配置
        style = self.config.get('style', {})
        plt.rcParams['axes.grid'] = style.get('grid', True)
        plt.rcParams['grid.alpha'] = style.get('grid_alpha', 0.3)
        plt.rcParams['grid.linestyle'] = style.get('grid_linestyle', '--')
        plt.rcParams['axes.spines.top'] = style.get('spines_top', False)
        plt.rcParams['axes.spines.right'] = style.get('spines_right', False)
        plt.rcParams['xtick.direction'] = style.get('tick_direction', 'in')
        plt.rcParams['ytick.direction'] = style.get('tick_direction', 'in')
    
    def subplots(self, 
                 nrows: int = 1, 
                 ncols: int = 1,
                 size: str = 'single',
                 **kwargs) -> Tuple[plt.Figure, Any]:
        """
        创建子图，自动应用期刊尺寸
        
        Args:
            nrows: 行数
            ncols: 列数
            size: 尺寸类型 ('single', 'double', 'wide', 'square')
            **kwargs: 其他参数
            
        Returns:
            (fig, axes): 图形和坐标轴对象
        """
        # 获取期刊推荐尺寸
        figsize = self.config.get('figure_size', {}).get(size, (3.5, 2.5))
        
        # 多子图时调整尺寸
        if nrows > 1 or ncols > 1:
            figsize = (figsize[0], figsize[0] * nrows / ncols * 1.2)
        
        dpi = self.config.get('output', {}).get('dpi', 300)
        
        self.fig, self.ax = plt.subplots(
            nrows=nrows, 
            ncols=ncols, 
            figsize=figsize, 
            dpi=dpi,
            **kwargs
        )
        
        return self.fig, self.ax
    
    def plot(self, 
             x, y=None, 
             label: Optional[str] = None,
             **kwargs) -> Any:
        """
        绘制折线图
        
        Args:
            x: X轴数据
            y: Y轴数据
            label: 图例标签
            **kwargs: 其他绘图参数
            
        Returns:
            线条对象
        """
        if self.ax is None:
            self.subplots()
            
        if y is None:
            y = x
            x = range(len(y))
        
        defaults = {'linewidth': 1.5}
        defaults.update(kwargs)
        
        lines = self.ax.plot(x, y, label=label, **defaults)
        return lines
    
    def scatter(self, 
                x, y,
                label: Optional[str] = None,
                **kwargs) -> Any:
        """绘制散点图"""
        if self.ax is None:
            self.subplots()
            
        defaults = {'s': 20, 'alpha': 0.6}
        defaults.update(kwargs)
        
        return self.ax.scatter(x, y, label=label, **defaults)
    
    def bar(self, 
            x, y,
            label: Optional[str] = None,
            **kwargs) -> Any:
        """绘制柱状图"""
        if self.ax is None:
            self.subplots()
            
        defaults = {'alpha': 0.8}
        defaults.update(kwargs)
        
        return self.ax.bar(x, y, label=label, **defaults)
    
    def hist(self, 
             x,
             bins: int = 20,
             **kwargs) -> Any:
        """绘制直方图"""
        if self.ax is None:
            self.subplots()
            
        defaults = {'alpha': 0.7, 'edgecolor': 'black'}
        defaults.update(kwargs)
        
        return self.ax.hist(x, bins=bins, **defaults)
    
    def get_colors(self, n: Optional[int] = None) -> List[str]:
        """
        获取当前场景的颜色循环
        
        Args:
            n: 需要的颜色数量，默认为全部
            
        Returns:
            颜色列表
        """
        color_cycle = self.config.get('color', {}).get('cycle', 
            ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#F0E442', '#56B4E9'])
        
        if n is None:
            return color_cycle
        else:
            # 如果需要的颜色数量超过可用颜色，循环使用
            return [color_cycle[i % len(color_cycle)] for i in range(n)]
    
    def set_labels(self, 
                   xlabel: Optional[str] = None,
                   ylabel: Optional[str] = None,
                   title: Optional[str] = None):
        """
        设置坐标轴标签和标题
        
        Args:
            xlabel: X轴标签
            ylabel: Y轴标签
            title: 图表标题
        """
        if self.ax is None:
            self.subplots()
            
        if xlabel:
            self.ax.set_xlabel(xlabel)
        if ylabel:
            self.ax.set_ylabel(ylabel)
        if title:
            self.ax.set_title(title)
    
    def legend(self, **kwargs):
        """添加图例"""
        if self.ax is not None:
            defaults = {'frameon': True, 'framealpha': 0.8}
            defaults.update(kwargs)
            self.ax.legend(**defaults)
    
    def grid(self, **kwargs):
        """添加网格"""
        if self.ax is not None:
            defaults = {'alpha': 0.3}
            defaults.update(kwargs)
            self.ax.grid(**defaults)
    
    def save(self, 
             filepath: str,
             formats: Optional[List[str]] = None,
             dpi: Optional[int] = None):
        """
        保存图表
        
        Args:
            filepath: 文件路径（不含扩展名）
            formats: 格式列表，默认 ['png', 'jpg', 'svg', 'pdf', 'eps', 'tiff']
            dpi: 分辨率，默认使用期刊配置
        """
        if self.fig is None:
            raise RuntimeError("没有可保存的图表，请先创建图表")
        
        # 默认格式：六种学术出版常用格式
        if formats is None:
            formats = ['png', 'jpg', 'svg', 'pdf', 'eps', 'tiff']
        
        # 解析路径
        filepath = Path(filepath)
        if not filepath.is_absolute():
            filepath = self.output_dir / filepath
        
        # 创建输出目录
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        # 保存多格式
        paths = self.output_manager.save_multiformat(
            self.fig,
            filepath,
            formats=formats,
            dpi=dpi
        )
        
        # 自动合规检查
        if self.auto_check:
            report = check_compliance(self.fig, self.config)
            if not report.passed:
                print(f"警告: 合规性检查未通过")
                for error in report.errors:
                    print(f"  - {error}")
        
        print(f"已保存文件:")
        for path in paths:
            print(f"  - {path}")
        
        return paths
    
    def close(self):
        """关闭图表"""
        if self.fig is not None:
            plt.close(self.fig)
            self.fig = None
            self.ax = None
    
    @staticmethod
    def list_publications() -> List[str]:
        """列出支持的出版物类型"""
        return list_supported_publications()
    
    # 保持向后兼容的别名
    list_journals = list_publications
    
    @staticmethod
    def quick_plot(x, y=None, 
                   publication: str = 'default',
                   xlabel: str = '',
                   ylabel: str = '',
                   title: str = '',
                   label: str = '',
                   output: str = 'output/figure',
                   **kwargs):
        """
        快速绘图 - 一行代码生成图表
        
        Args:
            x: X轴数据
            y: Y轴数据
            publication: 出版物类型 ('cea', 'ieee', 'nature', 'thesis', 'book', 'default')
            xlabel, ylabel, title: 标签
            label: 图例
            output: 输出路径
            **kwargs: 其他参数
        """
        with PlotTool(publication) as tool:
            tool.plot(x, y, label=label, **kwargs)
            tool.set_labels(xlabel, ylabel, title)
            if label:
                tool.legend()
            tool.grid()
            tool.save(output)


def plot_with_config(config_file: str,
                     plot_func: Callable,
                     output: str = 'output/figure'):
    """
    使用配置文件生成图表
    
    Args:
        config_file: 配置文件路径
        plot_func: 绘图函数，接收ax参数
        output: 输出路径
    """
    tool = PlotTool(config_file=config_file)
    with tool:
        fig, ax = tool.subplots()
        plot_func(ax)
        tool.save(output)
