"""
样式配置模块

整合颜色、字体、线条、图表样式、保存配置和尺寸配置。
为学术图表提供统一的样式管理。
"""

from typing import Dict, List, Any, Tuple

# ====================
# 1. 颜色配置
# ====================

# 主色板定义
MAIN_PALETTE: List[str] = [
    '#1F77B4',  # 蓝色
    '#FF7F0E',  # 橙色
    '#2CA02C',  # 绿色
    '#D62728',  # 红色
    '#9467BD',  # 紫色
    '#8C564B',  # 棕色
    '#E377C2',  # 粉色
    '#17BECF',  # 青色
]

# 色盲友好色板
COLORBLIND_PALETTE: List[str] = [
    '#006BA4',  # 深蓝
    '#FF800E',  # 深橙
    '#2CA02C',  # 绿色
    '#D62728',  # 红色
    '#5F9ED1',  # 浅蓝
    '#C85200',  # 深橙
    '#9467BD',  # 紫色
    '#17BECF',  # 青色
]

# 语义颜色映射
SEMANTIC_COLORS: Dict[str, Any] = {
    '模型': {
        '线性回归': MAIN_PALETTE[0],
        '决策树': MAIN_PALETTE[1],
        '随机森林': MAIN_PALETTE[2],
        '逻辑回归': MAIN_PALETTE[3],
        '支持向量机': MAIN_PALETTE[4],
        '梯度提升': MAIN_PALETTE[5],
    },
    '数据集': {
        '训练集': MAIN_PALETTE[0],
        '测试集': MAIN_PALETTE[1],
        '验证集': MAIN_PALETTE[2],
    },
    '功能': {
        'train': MAIN_PALETTE[0],
        'test': MAIN_PALETTE[1],
        'prediction': MAIN_PALETTE[2],
        'positive': MAIN_PALETTE[2],
        'negative': MAIN_PALETTE[3],
    },
}

# 颜色映射表
COLORMAPS: Dict[str, str] = {
    'diverging': 'RdBu',
    'sequential': 'Blues',
    'qualitative': 'Set1',
    'heatmap': 'coolwarm',
    'colorblind': 'Set2',
}

# 默认颜色循环
DEFAULT_COLOR_CYCLE: List[str] = MAIN_PALETTE

# ====================
# 2. 字体配置
# ====================

FONT_CONFIG: Dict[str, Any] = {
    # 字体族
    'family': ['SimSun', 'Times New Roman', 'serif'],
    'serif': ['SimSun', 'Times New Roman', 'STSong', 'DejaVu Serif'],
    'sans-serif': ['SimSun', 'Microsoft YaHei', 'Arial', 'DejaVu Sans'],
    
    # 字体大小
    'titlesize': 12,
    'labelsize': 10,
    'ticksize': 9,
    'legendsize': 9,
    
    # 字体样式
    'titleweight': 'bold',
    'labelweight': 'normal',
    'tickweight': 'normal',
    
    # 其他属性
    'linewidth': 1.0,
    'letter_spacing': 0.02,
    'line_spacing': 1.2,
    'math_fontfamily': 'cm',
}

# ====================
# 3. 线条配置
# ====================

LINE_STYLES: Dict[str, str] = {
    'solid': '-',
    'dashed': '--',
    'dashdot': '-.',
    'dotted': ':',
    'train': '-',
    'test': '--',
}

LINE_WIDTHS: Dict[str, float] = {
    'major': 2.0,
    'minor': 1.5,
    'grid': 0.5,
    'border': 1.0,
}

MARKER_STYLES: Dict[str, str] = {
    'circle': 'o',
    'square': 's',
    'triangle': '^',
    'diamond': 'D',
    'cross': 'x',
}

MARKER_SIZES: Dict[str, int] = {
    'major': 8,
    'minor': 6,
    'scatter': 50,
}

# ====================
# 4. 图表样式配置
# ====================

GRID_CONFIG: Dict[str, Any] = {
    'linestyle': '--',
    'linewidth': 0.5,
    'alpha': 0.3,
}

SPINE_CONFIG: Dict[str, Any] = {
    'linewidth': 0.8,
    'top': False,
    'right': False,
}

LEGEND_CONFIG: Dict[str, Any] = {
    'loc': 'best',
    'frameon': True,
    'framealpha': 0.8,
    'edgecolor': 'gray',
}

# ====================
# 5. 保存配置
# ====================

SAVE_CONFIG: Dict[str, Any] = {
    'dpi': 300,
    'bbox_inches': 'tight',
    'pad_inches': 0.1,
    'facecolor': 'white',
    'transparent': False,
    
    'formats': {
        'png': {'format': 'png', 'dpi': 300},
        'jpg': {'format': 'jpg', 'quality': 95},
        'svg': {'format': 'svg', 'fonttype': 'path'},
        'pdf': {'format': 'pdf', 'dpi': 300},
        'eps': {'format': 'eps'},
    }
}

# 支持的格式
SUPPORTED_FORMATS: List[str] = ['png', 'jpg', 'jpeg', 'svg', 'pdf', 'eps', 'tiff']

# ====================
# 6. 尺寸配置
# ====================

FIGURE_SIZES: Dict[str, Tuple[float, float]] = {
    'single': (3.5, 2.5),
    'double': (7.0, 2.5),
    'wide': (5.0, 2.5),
    'square': (3.5, 3.5),
    'small': (2.5, 2.0),
}

# 期刊推荐尺寸（英寸）
JOURNAL_FIGURE_SIZES: Dict[str, Dict[str, Tuple[float, float]]] = {
    'cea': {
        'single': (3.15, 2.36),
        'double': (6.3, 2.36),
    },
    'ieee': {
        'single': (3.5, 2.5),
        'double': (7.0, 2.625),
    },
    'nature': {
        'single': (3.5, 2.5),
        'double': (7.2, 3.0),
    },
}

# ====================
# 7. 便捷函数
# ====================

def get_color(color_name: str, category: str = '功能') -> str:
    """获取指定名称的颜色"""
    if category in SEMANTIC_COLORS:
        return SEMANTIC_COLORS[category].get(color_name, MAIN_PALETTE[0])
    return MAIN_PALETTE[0]


def get_figure_size(size_type: str = 'single', journal: str = None) -> Tuple[float, float]:
    """获取图形尺寸"""
    if journal and journal in JOURNAL_FIGURE_SIZES:
        return JOURNAL_FIGURE_SIZES[journal].get(size_type, FIGURE_SIZES['single'])
    return FIGURE_SIZES.get(size_type, FIGURE_SIZES['single'])


def get_line_style(style_name: str) -> str:
    """获取线型"""
    return LINE_STYLES.get(style_name, '-')


def get_line_width(width_name: str) -> float:
    """获取线宽"""
    return LINE_WIDTHS.get(width_name, 1.5)


def get_marker(marker_name: str) -> str:
    """获取标记样式"""
    return MARKER_STYLES.get(marker_name, 'o')


def get_marker_size(size_name: str) -> int:
    """获取标记大小"""
    return MARKER_SIZES.get(size_name, 6)
