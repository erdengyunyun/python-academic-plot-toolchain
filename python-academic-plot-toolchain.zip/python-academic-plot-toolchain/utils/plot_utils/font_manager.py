"""
字体管理模块

提供字体检测、选择和回退机制，确保在不同系统上都能找到合适的字体。
"""

import matplotlib.font_manager as fm
from typing import List, Optional, Dict, Set
import warnings


class FontManager:
    """
    字体管理器
    
    负责检测系统可用字体，提供智能字体选择和回退机制。
    """
    
    # 缓存已检测到的系统字体
    _available_fonts: Optional[Set[str]] = None
    
    # 默认字体回退方案 - 跨平台支持
    # 优先级：Windows字体 > macOS字体 > Linux字体 > 开源字体 > 通用字体族
    DEFAULT_FALLBACKS = {
        # 中文无衬线字体（黑体类）
        'chinese_sans': [
            # Windows
            'SimHei', 'Microsoft YaHei', 'Microsoft YaHei UI',
            # macOS
            'Heiti SC', 'Heiti TC', 'PingFang SC', 'PingFang TC',
            # Linux
            'Noto Sans CJK SC', 'Noto Sans CJK TC', 'Noto Sans CJK JP',
            'WenQuanYi Micro Hei', 'WenQuanYi Zen Hei',
            # 开源字体
            'Source Han Sans SC', 'Source Han Sans TC',
            # 通用
            'DejaVu Sans', 'sans-serif'
        ],
        # 中文衬线字体（宋体类）
        # 中文出版通用以宋体（SimSun）为优先，方正书宋为期刊特定要求
        'chinese_serif': [
            # Windows - 中文出版通用宋体优先
            'SimSun', 'NSimSun', 'STSong',
            # 方正书宋（期刊特定要求，优先级次于SimSun）
            'FZShuSong-Z01', 'FZFangSong-Z02',
            # macOS
            'Songti SC', 'Songti TC',
            # Linux
            'Noto Serif CJK SC', 'Noto Serif CJK TC',
            'WenQuanYi Zen Hei',
            # 开源字体
            'Source Han Serif SC', 'Source Han Serif TC',
            # 通用
            'DejaVu Serif', 'serif'
        ],
        # 英文无衬线字体
        'english_sans': [
            # Windows/macOS
            'Arial', 'Helvetica', 'Helvetica Neue',
            # Linux
            'Liberation Sans', 'Nimbus Sans',
            # 通用
            'DejaVu Sans', 'sans-serif'
        ],
        # 英文衬线字体
        'english_serif': [
            # Windows/macOS
            'Times New Roman', 'Times',
            # Linux
            'Liberation Serif', 'Nimbus Roman',
            # 通用
            'DejaVu Serif', 'serif'
        ],
        # 等宽字体
        'monospace': [
            # Windows/macOS
            'Consolas', 'Monaco', 'Courier New',
            # Linux
            'Liberation Mono', 'Nimbus Mono',
            # 通用
            'DejaVu Sans Mono', 'monospace'
        ],
    }
    
    @classmethod
    def get_available_fonts(cls) -> Set[str]:
        """
        获取系统中所有可用的字体名称
        
        Returns:
            Set[str]: 可用字体名称集合
        """
        if cls._available_fonts is None:
            cls._available_fonts = cls._scan_system_fonts()
        return cls._available_fonts
    
    @classmethod
    def _scan_system_fonts(cls) -> Set[str]:
        """
        扫描系统中的所有字体
        
        Returns:
            Set[str]: 字体名称集合
        """
        fonts = set()
        try:
            # 获取matplotlib字体管理器中的所有字体
            for font in fm.fontManager.ttflist:
                fonts.add(font.name)
                # 也添加字体族名
                if hasattr(font, 'family') and font.family:
                    fonts.add(font.family)
            
            # 添加通用字体族
            fonts.update(['sans-serif', 'serif', 'monospace', 'cursive', 'fantasy'])
            
        except Exception as e:
            warnings.warn(f"扫描系统字体时出错: {e}")
            # 返回基本字体作为后备
            fonts = {'Arial', 'Helvetica', 'Times New Roman', 'DejaVu Sans', 
                     'DejaVu Serif', 'sans-serif', 'serif', 'monospace'}
        
        return fonts
    
    @classmethod
    def is_font_available(cls, font_name: str) -> bool:
        """
        检查指定字体是否可用
        
        Args:
            font_name: 字体名称
            
        Returns:
            bool: 字体是否可用
        """
        # 通用字体族始终可用
        if font_name in ['sans-serif', 'serif', 'monospace', 'cursive', 'fantasy']:
            return True
        
        available = cls.get_available_fonts()
        
        # 精确匹配
        if font_name in available:
            return True
        
        # 忽略大小写的匹配
        font_lower = font_name.lower()
        for avail_font in available:
            if avail_font.lower() == font_lower:
                return True
        
        return False
    
    @classmethod
    def select_font(cls, font_list: List[str]) -> str:
        """
        从字体列表中选择第一个可用的字体
        
        Args:
            font_list: 字体名称列表，按优先级排序
            
        Returns:
            str: 第一个可用的字体名称
            
        示例:
            >>> select_font(['SimHei', 'Microsoft YaHei', 'Arial'])
            'Microsoft YaHei'  # 如果SimHei不可用但Microsoft YaHei可用
        """
        if not font_list:
            return 'sans-serif'
        
        for font in font_list:
            if cls.is_font_available(font):
                return font
        
        # 如果都不可用，返回最后一个（通常是通用字体族如'sans-serif'）
        return font_list[-1] if font_list else 'sans-serif'
    
    @classmethod
    def select_fonts(cls, font_list: List[str]) -> List[str]:
        """
        从字体列表中选择所有可用字体，保持原有顺序
        
        Args:
            font_list: 字体名称列表
            
        Returns:
            List[str]: 所有可用字体的列表
        """
        available = [f for f in font_list if cls.is_font_available(f)]
        
        # 确保至少有一个字体可用
        if not available:
            available = ['sans-serif']
        
        return available
    
    @classmethod
    def get_font_config(cls, font_prefs: Dict) -> Dict:
        """
        根据字体偏好配置，生成实际可用的字体配置
        
        Args:
            font_prefs: 字体偏好配置，包含 'family', 'sans-serif', 'serif', 'monospace' 等
            
        Returns:
            Dict: 实际可用的字体配置
        """
        config = {}
        
        # 处理主字体族
        if 'family' in font_prefs:
            family = font_prefs['family']
            if isinstance(family, list):
                # 选择第一个可用的字体族
                config['family'] = [cls.select_font(family)]
            else:
                config['family'] = [family] if cls.is_font_available(family) else ['sans-serif']
        
        # 处理无衬线字体
        if 'sans-serif' in font_prefs:
            sans_serif = font_prefs['sans-serif']
            if isinstance(sans_serif, list):
                config['sans-serif'] = cls.select_fonts(sans_serif)
            else:
                config['sans-serif'] = [sans_serif] if cls.is_font_available(sans_serif) else ['DejaVu Sans']
        
        # 处理衬线字体
        if 'serif' in font_prefs:
            serif = font_prefs['serif']
            if isinstance(serif, list):
                config['serif'] = cls.select_fonts(serif)
            else:
                config['serif'] = [serif] if cls.is_font_available(serif) else ['DejaVu Serif']
        
        # 处理等宽字体
        if 'monospace' in font_prefs:
            monospace = font_prefs['monospace']
            if isinstance(monospace, list):
                config['monospace'] = cls.select_fonts(monospace)
            else:
                config['monospace'] = [monospace] if cls.is_font_available(monospace) else ['monospace']
        
        # 复制其他配置（字号、字重等）
        for key in ['titlesize', 'labelsize', 'ticksize', 'legendsize', 
                    'titleweight', 'labelweight', 'embed', 'subset']:
            if key in font_prefs:
                config[key] = font_prefs[key]
        
        return config
    
    @classmethod
    def refresh_font_cache(cls):
        """
        刷新字体缓存
        
        在系统字体发生变化时调用
        """
        cls._available_fonts = None
        # 强制matplotlib重新扫描字体
        fm._rebuild()


def get_available_fonts() -> Set[str]:
    """
    获取系统中所有可用的字体名称（便捷函数）
    
    Returns:
        Set[str]: 可用字体名称集合
    """
    return FontManager.get_available_fonts()


def is_font_available(font_name: str) -> bool:
    """
    检查指定字体是否可用（便捷函数）
    
    Args:
        font_name: 字体名称
        
    Returns:
        bool: 字体是否可用
    """
    return FontManager.is_font_available(font_name)


def select_font(font_list: List[str]) -> str:
    """
    从字体列表中选择第一个可用的字体（便捷函数）
    
    Args:
        font_list: 字体名称列表
        
    Returns:
        str: 第一个可用的字体名称
    """
    return FontManager.select_font(font_list)


def get_font_config(font_prefs: Dict) -> Dict:
    """
    根据字体偏好配置，生成实际可用的字体配置（便捷函数）
    
    Args:
        font_prefs: 字体偏好配置
        
    Returns:
        Dict: 实际可用的字体配置
    """
    return FontManager.get_font_config(font_prefs)
