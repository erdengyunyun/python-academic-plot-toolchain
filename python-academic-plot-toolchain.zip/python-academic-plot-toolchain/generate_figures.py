"""
生成论文中的图表
- 图1: 系统三层架构与模块关系图
- 图2: 可用性评估实验结果

使用CEA模板，保存到output/figures
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from utils.plot_utils import PlotTool


def generate_figure1_architecture():
    """
    图1: 系统三层架构与模块关系图
    根据论文2.2节描述的三层架构绘制
    设计原则：配置驱动、上下文隔离、出版合规、跨平台兼容
    """
    print("生成图1: 系统三层架构与模块关系图...")
    
    with PlotTool('cea') as tool:
        # 创建图形
        fig, ax = tool.subplots(size='double')
        ax.set_xlim(0, 10)
        ax.set_ylim(0, 14)
        ax.axis('off')
        
        # 定义颜色 - 根据论文三层架构
        color_data = '#E8F8F5'      # 配置数据层 - 浅青
        color_core = '#FFF4E6'      # 核心功能层 - 浅橙
        color_user = '#E8F4F8'      # 用户接口层 - 浅蓝
        color_font = '#FADBD8'      # 字体管理 - 浅红
        
        # 绘制配置数据层（最底层）
        data_box = FancyBboxPatch((0.5, 0.5), 9, 2,
                                   boxstyle="round,pad=0.1",
                                   facecolor=color_data,
                                   edgecolor='#333', linewidth=2)
        ax.add_patch(data_box)
        ax.text(5, 2.0, '配置数据层', ha='center', va='center',
                fontsize=11, fontweight='bold')
        ax.text(5, 1.2, 'YAML/JSON配置文件（cea, ieee, nature等模板）\n支持自定义与扩展',
                ha='center', va='center', fontsize=7)
        
        # 绘制核心功能层（中间层）- 包含四个模块
        core_box = FancyBboxPatch((0.5, 2.8), 9, 5.5,
                                   boxstyle="round,pad=0.1",
                                   facecolor=color_core,
                                   edgecolor='#333', linewidth=2)
        ax.add_patch(core_box)
        ax.text(5, 7.8, '核心功能层', ha='center', va='center',
                fontsize=11, fontweight='bold')
        
        # 统一模块间距：从0.7开始，每个模块宽2.0，间距0.3
        # 配置管理模块
        config_box = FancyBboxPatch((0.7, 3.3), 2.0, 3.8,
                                     boxstyle="round,pad=0.05",
                                     facecolor='#FFE6CC',
                                     edgecolor='#666', linewidth=1.5)
        ax.add_patch(config_box)
        ax.text(1.7, 6.6, '配置管理模块', ha='center', va='center',
                fontsize=9)  # 移除粗体
        ax.text(1.7, 5.2, 'ConfigManager\nPlotConfigContext\n加载·验证·合并',
                ha='center', va='center', fontsize=7)
        
        # 绘图引擎模块
        engine_box = FancyBboxPatch((3.0, 3.3), 2.0, 3.8,
                                     boxstyle="round,pad=0.05",
                                     facecolor='#D5F5E3',
                                     edgecolor='#666', linewidth=1.5)
        ax.add_patch(engine_box)
        ax.text(4.0, 6.6, '绘图引擎模块', ha='center', va='center',
                fontsize=9)  # 移除粗体
        ax.text(4.0, 5.2, 'Matplotlib\n配置上下文\n隔离绘图',
                ha='center', va='center', fontsize=7)
        
        # 输出管理模块
        output_box = FancyBboxPatch((5.3, 3.3), 2.0, 3.8,
                                     boxstyle="round,pad=0.05",
                                     facecolor='#E8DAEF',
                                     edgecolor='#666', linewidth=1.5)
        ax.add_patch(output_box)
        ax.text(6.3, 6.6, '输出管理模块', ha='center', va='center',
                fontsize=9)  # 移除粗体
        ax.text(6.3, 5.2, 'PNG/SVG/PDF/EPS\n合规性检查\n出版就绪',
                ha='center', va='center', fontsize=7)
        
        # 字体管理模块 - 改为横向显示
        font_box = FancyBboxPatch((7.6, 3.3), 1.6, 3.8,
                                   boxstyle="round,pad=0.05",
                                   facecolor=color_font,
                                   edgecolor='#666', linewidth=1.5)
        ax.add_patch(font_box)
        ax.text(8.4, 6.6, '字体管理', ha='center', va='center',
                fontsize=9)  # 移除粗体
        ax.text(8.4, 5.2, 'FontManager\n跨平台\n字体回退', 
                ha='center', va='center', fontsize=7)
        
        # 绘制用户接口层（最上层）- 增加高度避免重叠
        user_box = FancyBboxPatch((0.5, 8.8), 9, 4.0,
                                   boxstyle="round,pad=0.1",
                                   facecolor=color_user,
                                   edgecolor='#333', linewidth=2)
        ax.add_patch(user_box)
        ax.text(5, 12.2, '用户接口层', ha='center', va='center',
                fontsize=11, fontweight='bold')
        
        # 用户接口层内部两个部分 - 大幅增加间距避免重叠
        ax.text(2.5, 11.0, 'PlotTool类', ha='center', va='center',
                fontsize=10)  # 移除粗体
        ax.text(2.5, 9.8, '链式调用', ha='center', va='center',
                fontsize=8)
        ax.text(2.5, 9.2, '极简API', ha='center', va='center',
                fontsize=8)
        
        ax.text(7.5, 11.0, '配置驱动模式', ha='center', va='center',
                fontsize=10)  # 移除粗体
        ax.text(7.5, 9.8, '高级定制', ha='center', va='center',
                fontsize=8)
        ax.text(7.5, 9.2, '直接配置', ha='center', va='center',
                fontsize=8)
        
        # 绘制箭头连接 - 使用双向箭头表示交互
        arrow_props = dict(arrowstyle='<->', lw=1.5, color='#333',
                          connectionstyle="arc3,rad=0")
        arrow_props_dashed = dict(arrowstyle='<->', lw=1.5, color='#666',
                                  linestyle='dashed', connectionstyle="arc3,rad=0")
        
        # 用户接口层 <-> 核心功能层各模块（双向交互）
        ax.annotate('', xy=(1.7, 7.1), xytext=(2.5, 10.5),
                   arrowprops=arrow_props)
        ax.annotate('', xy=(4.0, 7.1), xytext=(5, 10.8),
                   arrowprops=arrow_props)
        ax.annotate('', xy=(6.3, 7.1), xytext=(7.5, 10.5),
                   arrowprops=arrow_props)
        
        # 核心功能层 <-> 配置数据层（双向交互：读取配置、写入状态）
        ax.annotate('', xy=(5, 2.5), xytext=(5, 3.3),
                   arrowprops=arrow_props)
        
        # 字体管理模块 <-> 各模块（双向支持关系）
        ax.annotate('', xy=(4.0, 5.2), xytext=(7.6, 5.2),
                   arrowprops=arrow_props_dashed)
        ax.annotate('', xy=(6.3, 5.2), xytext=(7.6, 5.2),
                   arrowprops=arrow_props_dashed)
        
        # 添加设计原则标注
        principles_text = ('设计原则：配置驱动 | 上下文隔离 | 出版合规 | 跨平台兼容')
        ax.text(5, 0.1, principles_text, ha='center', va='center',
                fontsize=8, style='italic', color='#555',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='#F0F0F0', alpha=0.7))
        
        # 添加标题
        ax.set_title('系统三层架构与模块关系图', fontsize=14, fontweight='bold', pad=20)
        
        # 保存
        tool.save('output/figures/figure1_architecture')
        print("  ✓ 已保存到 output/figures/figure1_architecture.*")


def generate_figure2_usability():
    """
    图2: 可用性评估实验结果
    """
    print("生成图2: 可用性评估实验结果...")
    
    with PlotTool('cea') as tool:
        fig, axes = tool.subplots(nrows=1, ncols=2, size='double')
        
        # 数据
        categories = ['任务完成时间\n(秒)', '代码行数', '易用性评分', 
                     '学习效率评分', '出错率评分', '总体满意度']
        native_values = [45.2, 18, 6.2, 5.5, 7.5, 6.5]
        tool_values = [28.6, 8, 8.8, 9.0, 2.0, 8.9]
        
        x = np.arange(len(categories))
        width = 0.35
        
        # 子图1: 柱状图对比
        bars1 = axes[0].bar(x - width/2, native_values, width, 
                           label='原生Matplotlib', color='#D55E00', alpha=0.8)
        bars2 = axes[0].bar(x + width/2, tool_values, width,
                           label='本工具链', color='#0072B2', alpha=0.8)
        
        axes[0].set_ylabel('数值')
        axes[0].set_title('(a) 各指标对比')
        axes[0].set_xticks(x)
        axes[0].set_xticklabels(categories, fontsize=7)
        axes[0].legend(loc='upper right', frameon=True)
        axes[0].grid(True, axis='y', alpha=0.3)
        
        # 添加数值标签
        for bars in [bars1, bars2]:
            for bar in bars:
                height = bar.get_height()
                axes[0].annotate(f'{height:.1f}',
                                xy=(bar.get_x() + bar.get_width() / 2, height),
                                xytext=(0, 3),
                                textcoords="offset points",
                                ha='center', va='bottom', fontsize=6)
        
        # 子图2: 提升百分比
        improvements = [36.7, 55.6, 41.9, 63.6, 73.3, 36.9]
        colors = ['#009E73' if i > 0 else '#D55E00' for i in improvements]
        
        bars = axes[1].barh(categories, improvements, color=colors, alpha=0.8)
        axes[1].set_xlabel('提升百分比 (%)')
        axes[1].set_title('(b) 性能提升百分比')
        axes[1].grid(True, axis='x', alpha=0.3)
        
        # 添加数值标签
        for i, (bar, val) in enumerate(zip(bars, improvements)):
            width = bar.get_width()
            axes[1].annotate(f'{val:.1f}%',
                            xy=(width, bar.get_y() + bar.get_height()/2),
                            xytext=(3, 0),
                            textcoords="offset points",
                            ha='left', va='center', fontsize=7)
        
        # 添加注释
        axes[1].text(0.95, 0.05, '注：出错率越低越好\n其他指标越高越好',
                    transform=axes[1].transAxes, fontsize=7,
                    verticalalignment='bottom', horizontalalignment='right',
                    bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        plt.tight_layout()
        tool.save('output/figures/figure_usability_study')
        print("  ✓ 已保存到 output/figures/figure_usability_study.*")


if __name__ == '__main__':
    os.makedirs('output/figures/png', exist_ok=True)
    os.makedirs('output/figures/jpg', exist_ok=True)
    os.makedirs('output/figures/pdf', exist_ok=True)
    os.makedirs('output/figures/svg', exist_ok=True)
    os.makedirs('output/figures/eps', exist_ok=True)
    os.makedirs('output/figures/tiff', exist_ok=True)
    
    print("=" * 60)
    print("生成论文图表")
    print("=" * 60)
    
    generate_figure1_architecture()
    generate_figure2_usability()
    
    print("\n" + "=" * 60)
    print("所有图表生成完成！")
    print("=" * 60)
    print("\n生成的文件:")
    for fname in ['figure1_architecture', 'figure_usability_study']:
        print(f"\n{fname}:")
        for fmt in ['png', 'jpg', 'pdf', 'svg', 'eps', 'tiff']:
            path = f'output/figures/{fmt}/{fname}.{fmt}'
            if os.path.exists(path):
                size = os.path.getsize(path)
                print(f"  ✓ {fmt}: {size} bytes")
