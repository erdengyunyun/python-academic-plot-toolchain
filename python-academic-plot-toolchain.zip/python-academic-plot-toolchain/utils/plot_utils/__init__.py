"""
学术图表工具链 - 面向学术出版的Python图表工具

提供学术样式设置、图表保存、格式管理、出版物模板等功能，
支持期刊论文、学位论文、教材书籍等多种学术出版物的图表规范。

简化API使用示例:
    # 方式1: 极简模式（推荐）
    from utils.plot_utils import PlotTool
    
    with PlotTool('cea') as tool:
        tool.plot(x, y, label='数据')
        tool.set_labels('时间(s)', '振幅', '正弦函数')
        tool.save('output/figure')
    
    # 方式2: 一行代码快速绘图
    PlotTool.quick_plot(x, y, publication='ieee', 
                       xlabel='X', ylabel='Y', 
                       title='标题', output='output/fig')
    
    # 方式3: 配置文件驱动
    from utils.plot_utils import plot_with_config
    plot_with_config('config.yaml', my_plot_function)
"""

# 版本信息
__version__ = "3.0.0"

# ====================
# 简化API（推荐）
# ====================
from .plot_tool import (
    PlotTool,
    plot_with_config
)

# ====================
# 核心模块
# ====================

# 异常处理
from .exceptions import (
    PlotError,
    ConfigError,
    ValidationError,
    RenderError,
    OutputError,
)

# 配置管理
from .config_manager import (
    ConfigManager,
    PlotConfigContext,
    create_context,
    apply_publication_style,
    temporary_config
)

# 输出管理
from .output_manager import (
    OutputManager,
    ComplianceReport,
    save_figure,
    save_multiformat,
    check_compliance
)

# 出版物配置
from .configs.publication_config import (
    get_publication_config,
    list_supported_publications,
    get_publication_info,
    CEA_CONFIG,
    IEEE_CONFIG,
    NATURE_CONFIG,
    THESIS_CONFIG,
    BOOK_CONFIG,
    DEFAULT_CONFIG,
)

# 保持向后兼容的别名
get_journal_config = get_publication_config
list_supported_journals = list_supported_publications
get_journal_info = get_publication_info

# 样式配置
from .configs.style_config import (
    MAIN_PALETTE,
    COLORBLIND_PALETTE,
    DEFAULT_COLOR_CYCLE,
    get_color,
    get_figure_size,
)

# 字体管理
from .font_manager import (
    FontManager,
    get_available_fonts,
    is_font_available,
    select_font,
    get_font_config,
)

# 可选功能
from .annotation_utils import (
    add_annotation,
    add_text,
    add_vertical_line,
    add_horizontal_line,
    add_subplot_label,
)

from .multi_plot_layout import (
    calculate_optimal_layout,
    create_dynamic_grid,
)


# ====================
# 便捷函数
# ====================

def setup_publication_style(publication_name: str) -> PlotConfigContext:
    """
    设置出版物样式（便捷函数）
    
    Args:
        publication_name: 出版物类型（'cea', 'ieee', 'nature', 'thesis', 'book'等）
        
    Returns:
        PlotConfigContext: 配置上下文
        
    使用示例:
        >>> with setup_publication_style('cea'):
        ...     fig, ax = plt.subplots()
        ...     ax.plot([1, 2, 3], [1, 4, 9])
        ...     fig.savefig('output.pdf')
    """
    return apply_publication_style(publication_name)


# 保持向后兼容的别名
setup_journal_style = setup_publication_style


def get_figure_size(publication_name: str, size_type: str = 'single') -> tuple:
    """
    获取出版物推荐的图形尺寸
    
    Args:
        publication_name: 出版物类型
        size_type: 尺寸类型（'full', 'half', 'quarter', 'single', 'double'等）
        
    Returns:
        tuple: (width, height) 尺寸（英寸）
    """
    config = get_publication_config(publication_name)
    return config['figure_size'].get(size_type, config['figure_size']['single'])


# ====================
# 导出列表
# ====================

__all__ = [
    # 版本
    '__version__',
    
    # 简化API（推荐）
    'PlotTool',
    'plot_with_config',
    
    # 异常类
    'PlotError',
    'ConfigError',
    'ValidationError',
    'RenderError',
    'OutputError',
    
    # 配置管理
    'ConfigManager',
    'PlotConfigContext',
    'create_context',
    'apply_publication_style',
    'setup_publication_style',
    'temporary_config',
    
    # 输出管理
    'OutputManager',
    'ComplianceReport',
    'save_figure',
    'save_multiformat',
    'check_compliance',
    
    # 出版物配置
    'get_publication_config',
    'list_supported_publications',
    'get_publication_info',
    'get_figure_size',
    'CEA_CONFIG',
    'IEEE_CONFIG',
    'NATURE_CONFIG',
    'THESIS_CONFIG',
    'BOOK_CONFIG',
    'DEFAULT_CONFIG',
    
    # 向后兼容别名
    'get_journal_config',
    'list_supported_journals',
    'get_journal_info',
    'setup_journal_style',

    # 字体管理
    'FontManager',
    'get_available_fonts',
    'is_font_available',
    'select_font',
    'get_font_config',

    # 样式配置
    'MAIN_PALETTE',
    'COLORBLIND_PALETTE',
    'DEFAULT_COLOR_CYCLE',
    'get_color',
    
    # 可选功能
    'add_annotation',
    'add_text',
    'add_vertical_line',
    'add_horizontal_line',
    'add_subplot_label',
    'calculate_optimal_layout',
    'create_dynamic_grid',
]
