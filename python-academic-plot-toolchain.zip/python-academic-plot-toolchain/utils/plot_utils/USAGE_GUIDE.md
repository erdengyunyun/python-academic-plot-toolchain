# 绘图配置系统使用指南

## 一、配置系统概述

### 1. 配置体系结构

本配置系统采用清晰的层级结构和模块化设计，确保配置的一致性、可维护性和扩展性：

- **核心配置层**：定义基础视觉元素（颜色、字体、线型等）的原子配置，分布在多个模块化配置文件中
- **业务映射层**：建立"业务概念→视觉元素"的明确映射
- **场景模板层**：针对特定场景的预配置模板
- **图表类型层**：针对不同图表类型的特定配置

### 2. 模块化配置文件结构

配置系统已分解为多个模块化文件，便于维护和扩展：

```
configs/
├── __init__.py          # 配置导出文件
├── color_config.py       # 颜色配置
├── font_config.py        # 字体配置
├── line_config.py        # 线条样式配置
├── plot_style_config.py  # 图表样式配置
├── plot_type_config.py   # 图表类型特定配置
├── save_config.py        # 保存配置
├── size_config.py        # 图形尺寸配置
├── template_config.py    # 模板配置
└── textbook_config.py    # 教材视觉识别系统配置
```

### 3. 核心功能

- **统一颜色管理**：建立主色板和语义映射，确保颜色使用一致性，杜绝黑白灰色图
- **一站式配置API**：提供简单易用的配置函数，支持多种场景模板
- **教材特色支持**：建立教材视觉识别系统
- **高扩展性**：支持配置扩展和修改，便于定制
- **配置验证**：自动检查配置一致性和正确性
- **模块化设计**：配置分离到不同文件，便于维护和扩展

## 二、快速开始

### 1. 基础配置

```python
from utils.plot_utils.plot_config import setup_plot_config

# 设置全局配置
setup_plot_config(verbose=True)
```

### 2. 使用场景模板

```python
import matplotlib.pyplot as plt
from utils.plot_utils.plot_config import apply_template

# 创建图表
fig, ax = plt.subplots(figsize=(10, 6))

# 绘制数据
ax.plot([1, 2, 3], [4, 5, 6], label='训练集')
ax.plot([1, 2, 3], [3, 4, 5], label='测试集')

# 应用模板
apply_template(ax, template_name='learning_curve')

# 设置标题和标签
ax.set_title('学习曲线示例')
ax.set_xlabel('训练样本数')
ax.set_ylabel('准确率')

plt.show()
```

## 三、场景化使用示例

### 1. 模型对比场景

```python
import matplotlib.pyplot as plt
from utils.plot_utils.plot_config import apply_template, get_color

# 创建图表
fig, ax = plt.subplots(figsize=(10, 6))

# 模型名称和颜色映射
models = ['线性回归', '决策树', '随机森林']

# 绘制不同模型的性能
for model in models:
    # 获取模型对应的颜色
    color = get_color(model, category='模型')
    # 绘制数据
    ax.bar(model, [0.8, 0.75, 0.9][models.index(model)], color=color, width=0.8)

# 应用模型对比模板
apply_template(ax, template_name='model_comparison')

# 设置标题
ax.set_title('模型性能对比')

plt.show()
```

### 2. ROC/PR曲线场景

```python
import matplotlib.pyplot as plt
from utils.plot_utils.plot_config import apply_template, get_color

# 创建图表
fig, ax = plt.subplots(figsize=(10, 6))

# 绘制ROC曲线
ax.plot([0, 0.2, 0.4, 0.6, 0.8, 1.0], [0, 0.5, 0.7, 0.8, 0.9, 1.0], label='ROC曲线')

# 应用ROC/PR曲线模板
apply_template(ax, template_name='roc_pr')

# 设置标题
ax.set_title('ROC曲线示例')

plt.show()
```

### 3. 学习曲线场景

```python
import matplotlib.pyplot as plt
from utils.plot_utils.plot_config import apply_template, get_color

# 创建图表
fig, ax = plt.subplots(figsize=(10, 6))

# 绘制学习曲线
ax.plot([100, 200, 400, 800, 1600], [0.6, 0.7, 0.75, 0.8, 0.85], label='训练集')
ax.plot([100, 200, 400, 800, 1600], [0.5, 0.6, 0.65, 0.7, 0.75], label='测试集')

# 应用学习曲线模板
apply_template(ax, template_name='learning_curve')

# 设置标题和标签
ax.set_title('学习曲线示例')
ax.set_xlabel('训练样本数')
ax.set_ylabel('准确率')

plt.show()
```

## 四、最佳实践

### 1. 颜色使用最佳实践

- **优先使用语义颜色**：使用`get_color(name, category)`获取颜色，而不是直接使用色值
- **限制颜色数量**：一个图表中颜色数量不超过6个，避免视觉混乱
- **使用鲜艳彩色**：配置系统已移除黑白灰色，所有图表使用鲜艳的彩色
- **保持一致性**：同一模型在不同图表中使用相同颜色
- **默认颜色保障**：当颜色无法匹配时，系统会返回合适的默认彩色（蓝色）

### 2. 模板使用最佳实践

- **根据场景选择模板**：不同场景使用对应的模板，如模型对比使用`model_comparison`模板
- **避免过度定制**：尽量使用预定义模板，仅在必要时进行自定义
- **保持跨章节一致性**：同一本书或同一章节使用相同的模板和配置

### 3. 配置扩展最佳实践

- **使用update_config方法**：通过`update_config`方法扩展或修改配置，而不是直接修改源代码
- **验证配置**：修改配置后调用`validate_config`检查配置一致性
- **保留原始配置**：扩展配置时保留原始配置的结构，便于维护

## 五、常见问题解答

### 1. 如何添加新的模型颜色映射？

```python
from utils.plot_utils.plot_config import PlotConfig

# 更新配置
PlotConfig.update_config({
    'SEMANTIC_COLORS': {
        '模型': {
            '新模型': PlotConfig.MAIN_PALETTE[6]  # 使用主色板中的颜色
        }
    }
})
```

### 2. 如何修改图表默认尺寸？

```python
from utils.plot_utils.plot_config import PlotConfig

# 更新配置
PlotConfig.update_config({
    'FIGURE_SIZE': {
        'single': (12, 8)  # 修改单图表默认尺寸
    }
})
```

### 3. 如何验证配置是否正确？

```python
from utils.plot_utils.plot_config import PlotConfig

# 验证配置
is_valid = PlotConfig.validate_config()
print(f"配置是否有效: {is_valid}")
```

### 4. 如何获取完整配置？

```python
from utils.plot_utils.plot_config import PlotConfig

# 获取完整配置
config = PlotConfig.get_full_config()
print(config)
```

## 六、场景模板参考

| 模板名称 | 适用场景 | 主要特点 |
|---------|---------|---------|
| default | 默认场景 | 基础模板，适用于大多数情况 |
| data | 数据展示 | 增强数据可读性，适合数据分布展示 |
| model | 模型结果 | 突出模型性能，自动添加图例 |
| comparison | 比较图表 | 适合多组数据对比，自动添加图例 |
| simple | 简洁风格 | 无网格线，简洁样式，适合简单图表 |
| model_comparison | 模型对比 | 优化模型对比显示，支持多模型 |
| learning_curve | 学习曲线 | 优化学习曲线显示，添加网格线 |
| roc_pr | ROC/PR曲线 | 自动添加参考线，优化曲线显示 |

## 七、语义颜色参考

### 模型颜色

| 模型名称 | 颜色 | 说明 |
|---------|------|------|
| 线性回归 | #1F77B4 | 蓝色 |
| 决策树 | #FF7F0E | 橙色 |
| 随机森林 | #2CA02C | 绿色 |
| 逻辑回归 | #D62728 | 红色 |
| 支持向量机 | #9467BD | 紫色 |
| 梯度提升 | #8C564B | 棕色 |

### 数据集颜色

| 数据集名称 | 颜色 | 说明 |
|-----------|------|------|
| 训练集 | #1F77B4 | 蓝色 |
| 测试集 | #FF7F0E | 橙色 |
| 验证集 | #2CA02C | 绿色 |

### 功能颜色

| 功能名称 | 颜色 | 说明 |
|---------|------|------|
| train | #1F77B4 | 蓝色 - 训练数据 |
| test | #FF7F0E | 橙色 - 测试数据 |
| prediction | #2CA02C | 绿色 - 预测结果 |
| positive | #2CA02C | 绿色 - 正样本 |
| negative | #D62728 | 红色 - 负样本 |
| decision | #9467BD | 紫色 - 决策边界 |
| boundary | #8C564B | 棕色 - 边界线 |

### 主色板

| 索引 | 颜色 | 说明 |
|-----|------|------|
| 0 | #1F77B4 | 蓝色 |
| 1 | #FF7F0E | 橙色 |
| 2 | #2CA02C | 绿色 |
| 3 | #D62728 | 红色 |
| 4 | #9467BD | 紫色 |
| 5 | #8C564B | 棕色 |
| 6 | #E377C2 | 粉色 |
| 7 | #17BECF | 青色 |

## 八、版本历史

### v1.1.0
- **模块化配置设计**：将配置系统分解为多个模块化文件，便于维护和扩展
- **移除黑白灰色**：主色板和色盲友好色板中移除灰色调，使用鲜艳彩色
- **增强默认配置**：确保颜色无法匹配时返回合适的默认彩色
- **更新文档**：反映配置系统的最新变化，包括模块化结构和颜色使用最佳实践
- **改进配置验证**：确保配置一致性和正确性

### v1.0.0
- 重构配置体系，建立清晰的层级结构
- 统一颜色管理，建立主色板和语义映射
- 提供一站式配置API，支持多种场景模板
- 增强教材特色，建立教材视觉识别系统
- 提高扩展性与维护性，集中配置管理
- 编写文档，提供场景化指导和最佳实践
