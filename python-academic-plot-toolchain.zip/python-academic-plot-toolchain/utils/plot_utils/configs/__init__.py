"""
配置模块

提供出版物配置和样式配置。
"""

# 出版物配置
from .publication_config import (
    get_publication_config,
    list_supported_publications,
    get_publication_info,
    CEA_CONFIG,
    IEEE_CONFIG,
    NATURE_CONFIG,
    THESIS_CONFIG,
    BOOK_CONFIG,
    DEFAULT_CONFIG,
)

# 保持向后兼容的别名
get_journal_config = get_publication_config
list_supported_journals = list_supported_publications
get_journal_info = get_publication_info

# 样式配置
from .style_config import (
    # 颜色
    MAIN_PALETTE,
    COLORBLIND_PALETTE,
    SEMANTIC_COLORS,
    COLORMAPS,
    DEFAULT_COLOR_CYCLE,
    get_color,
    
    # 字体
    FONT_CONFIG,
    
    # 线条
    LINE_STYLES,
    LINE_WIDTHS,
    MARKER_STYLES,
    MARKER_SIZES,
    get_line_style,
    get_line_width,
    get_marker,
    get_marker_size,
    
    # 样式
    GRID_CONFIG,
    SPINE_CONFIG,
    LEGEND_CONFIG,
    
    # 保存
    SAVE_CONFIG,
    SUPPORTED_FORMATS,
    
    # 尺寸
    FIGURE_SIZES,
    JOURNAL_FIGURE_SIZES,
    get_figure_size,
)

__all__ = [
    # 出版物配置
    'get_publication_config',
    'list_supported_publications',
    'get_publication_info',
    'CEA_CONFIG',
    'IEEE_CONFIG',
    'NATURE_CONFIG',
    'THESIS_CONFIG',
    'BOOK_CONFIG',
    'DEFAULT_CONFIG',
    
    # 向后兼容别名
    'get_journal_config',
    'list_supported_journals',
    'get_journal_info',
    
    # 颜色
    'MAIN_PALETTE',
    'COLORBLIND_PALETTE',
    'SEMANTIC_COLORS',
    'COLORMAPS',
    'DEFAULT_COLOR_CYCLE',
    'get_color',
    
    # 字体
    'FONT_CONFIG',
    
    # 线条
    'LINE_STYLES',
    'LINE_WIDTHS',
    'MARKER_STYLES',
    'MARKER_SIZES',
    'get_line_style',
    'get_line_width',
    'get_marker',
    'get_marker_size',
    
    # 样式
    'GRID_CONFIG',
    'SPINE_CONFIG',
    'LEGEND_CONFIG',
    
    # 保存
    'SAVE_CONFIG',
    'SUPPORTED_FORMATS',
    
    # 尺寸
    'FIGURE_SIZES',
    'JOURNAL_FIGURE_SIZES',
    'get_figure_size',
]
