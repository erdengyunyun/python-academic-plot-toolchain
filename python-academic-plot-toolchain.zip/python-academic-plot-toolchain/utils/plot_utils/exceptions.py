"""
学术图表工具链异常处理模块

提供统一的异常处理机制，支持错误阶段追踪和详细错误信息。
"""

from typing import Optional


class PlotError(Exception):
    """
    图表工具链异常基类
    
    所有图表相关异常的基类，支持错误阶段追踪。
    
    Attributes:
        error_stage: 错误发生的阶段
        message: 错误信息
    """
    
    def __init__(self, stage: str, msg: str) -> None:
        """
        初始化异常
        
        Args:
            stage: 错误发生的阶段（如"配置加载"、"渲染"、"输出"等）
            msg: 错误信息
        """
        super().__init__(f"[{stage}] {msg}")
        self.error_stage = stage
        self.error_message = msg
    
    def __str__(self) -> str:
        return f"[{self.error_stage}] {self.error_message}"


class ConfigError(PlotError):
    """
    配置错误异常
    
    在配置加载、解析或验证过程中发生错误时抛出。
    """
    
    def __init__(self, msg: str, stage: str = "配置") -> None:
        super().__init__(stage, msg)


class ValidationError(PlotError):
    """
    验证错误异常
    
    在配置验证或合规性校验失败时抛出。
    """
    
    def __init__(self, msg: str, stage: str = "验证") -> None:
        super().__init__(stage, msg)


class RenderError(PlotError):
    """
    渲染错误异常
    
    在图表渲染过程中发生错误时抛出。
    """
    
    def __init__(self, msg: str, stage: str = "渲染") -> None:
        super().__init__(stage, msg)


class OutputError(PlotError):
    """
    输出错误异常
    
    在图表保存或格式转换过程中发生错误时抛出。
    """
    
    def __init__(self, msg: str, stage: str = "输出") -> None:
        super().__init__(stage, msg)


class ColorError(PlotError):
    """
    颜色处理错误异常
    
    在颜色计算或配色方案生成过程中发生错误时抛出。
    """
    
    def __init__(self, msg: str, stage: str = "颜色处理") -> None:
        super().__init__(stage, msg)


class TemplateError(PlotError):
    """
    模板错误异常
    
    在模板应用或模板配置过程中发生错误时抛出。
    """
    
    def __init__(self, msg: str, stage: str = "模板") -> None:
        super().__init__(stage, msg)
