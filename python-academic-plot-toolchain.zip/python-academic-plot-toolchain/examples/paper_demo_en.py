"""
Paper Complete Example Code (English Version)

This file contains all the example implementations from the paper
"Python Chart Toolchain for Academic Publishing: Design and Case Studies".
All labels are in English to avoid font issues.
"""

import numpy as np
import matplotlib.pyplot as plt
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.plot_utils import (
    # Journal styles
    setup_journal_style,
    get_figure_size,
    get_journal_config,
    list_supported_journals,
    get_journal_info,
    
    # Configuration management
    ConfigManager,
    PlotConfigContext,
    create_context,
    temporary_config,
    
    # Output management
    save_figure,
    save_multiformat,
    check_compliance,
    OutputManager,
    ComplianceReport,
    
    # Layout utilities
    calculate_optimal_layout,
    create_dynamic_grid,
)

from utils.plot_utils.configs.journal_config import (
    CEA_CONFIG,
    IEEE_CONFIG,
    NATURE_CONFIG
)


# ====================
# Example 1: Basic API Usage (Section 5.1)
# ====================
def example_1_basic_api():
    """
    Example 1: API Usage Example
    
    Demonstrates the complete workflow for generating a publication-ready
    chart with sine and cosine curves.
    Corresponds to Section 5.1 of the paper.
    """
    print("\n" + "=" * 70)
    print("Example 1: API Usage - CEA Journal Style")
    print("=" * 70)
    
    # 1. Apply journal standard template
    with setup_journal_style('cea'):
        # 2. Create canvas (automatically applies preset layout)
        fig, ax = plt.subplots(figsize=(3.15, 2.36), dpi=300)
        
        # 3. Plot data
        x = np.linspace(0, 10, 100)
        ax.plot(x, np.sin(x), label='sin(x)', linewidth=1.0)
        ax.plot(x, np.cos(x), label='cos(x)', linestyle='--', linewidth=1.0)
        
        # 4. Add legend and labels (styles are automatically unified)
        ax.legend(loc='best', frameon=True, framealpha=0.8)
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Amplitude')
        ax.set_title('Sine and Cosine Functions')
        ax.grid(True, alpha=0.3, linestyle='--')
        
        # 5. Compliance check
        print("\nCompliance Check:")
        report = check_compliance(fig, CEA_CONFIG)
        print(report)
        
        # 6. One-click multi-format output (PDF/SVG/PNG)
        output_dir = "output/example1_en"
        os.makedirs(output_dir, exist_ok=True)
        
        paths = save_multiformat(
            fig,
            f"{output_dir}/trigonometric",
            formats=['png', 'svg', 'pdf', 'eps'],
            dpi=300
        )
        
        print(f"\nSaved files:")
        for path in paths:
            print(f"  - {path}")
        
        plt.close(fig)
    
    print("\nExample 1 completed!\n")


# ====================
# Example 2: Multi-Subplot Composition (Section 5.2)
# ====================
def example_2_multi_subplot():
    """
    Example 2: Multi-Panel Figure Composition
    
    Generates a composite figure containing four subplots showing different
    statistical perspectives of the same dataset.
    Corresponds to Sections 3.2 and 5.2 of the paper.
    """
    print("\n" + "=" * 70)
    print("Example 2: Multi-Panel Figure - Nature/Science Journal Style")
    print("=" * 70)
    
    with setup_journal_style('nature'):
        # Get Nature single-column size and adjust height
        figsize = get_figure_size('nature', 'single')
        figsize = (figsize[0], figsize[0] * 1.2)
        
        # Create 2x2 subplot grid
        fig, axes = plt.subplots(2, 2, figsize=figsize, dpi=300)
        fig.patch.set_facecolor('white')
        
        # Generate data
        np.random.seed(42)
        x = np.linspace(0, 10, 100)
        
        # Subplot 1: Line plot
        axes[0, 0].plot(x, np.sin(x), label='sin(x)', 
                       linewidth=1.2, color='#0072B2')
        axes[0, 0].plot(x, np.cos(x), label='cos(x)', 
                       linewidth=1.2, linestyle='--', color='#D55E00')
        axes[0, 0].set_xlabel('X')
        axes[0, 0].set_ylabel('Y')
        axes[0, 0].set_title('(a) Trigonometric Functions')
        axes[0, 0].legend(fontsize=6)
        axes[0, 0].grid(True, alpha=0.3)
        
        # Subplot 2: Scatter plot
        x_scatter = np.random.randn(50)
        y_scatter = np.random.randn(50)
        axes[0, 1].scatter(x_scatter, y_scatter, 
                          alpha=0.6, s=20, color='#009E73')
        axes[0, 1].set_xlabel('X')
        axes[0, 1].set_ylabel('Y')
        axes[0, 1].set_title('(b) Scatter Distribution')
        axes[0, 1].grid(True, alpha=0.3)
        
        # Subplot 3: Histogram
        data = np.random.normal(0, 1, 1000)
        axes[1, 0].hist(data, bins=20, alpha=0.7, 
                       color='#0072B2', edgecolor='black')
        axes[1, 0].set_xlabel('Value')
        axes[1, 0].set_ylabel('Frequency')
        axes[1, 0].set_title('(c) Data Distribution')
        axes[1, 0].grid(True, axis='y', alpha=0.3)
        
        # Subplot 4: Box plot
        data_box = [np.random.normal(0, 1, 100) 
                    for _ in range(3)]
        bp = axes[1, 1].boxplot(data_box, patch_artist=True)
        colors = ['#0072B2', '#D55E00', '#009E73']
        for patch, color in zip(bp['boxes'], colors):
            patch.set_facecolor(color)
        axes[1, 1].set_xlabel('Category')
        axes[1, 1].set_ylabel('Value')
        axes[1, 1].set_title('(d) Box Plot')
        axes[1, 1].grid(True, axis='y', alpha=0.3)
        
        plt.tight_layout()
        
        # Save
        output_dir = "output/example2_en"
        os.makedirs(output_dir, exist_ok=True)
        
        paths = save_multiformat(
            fig,
            f"{output_dir}/multi_panel",
            formats=['png', 'svg', 'pdf', 'eps'],
            dpi=300
        )
        
        print(f"\nSaved files:")
        for path in paths:
            print(f"  - {path}")
        
        plt.close(fig)
    
    print("\nExample 2 completed!\n")


# ====================
# Example 3: IEEE Performance Comparison
# ====================
def example_3_ieee_performance():
    """
    Example 3: IEEE Transactions Journal Style - Performance Comparison
    
    Shows performance comparison of different methods using bar chart.
    Corresponds to Section 3.2 of the paper.
    """
    print("\n" + "=" * 70)
    print("Example 3: IEEE Transactions Style - Performance Comparison")
    print("=" * 70)
    
    with setup_journal_style('ieee'):
        # IEEE double-column figure size
        figsize = get_figure_size('ieee', 'double')
        
        fig, ax = plt.subplots(figsize=figsize, dpi=300)
        
        # Generate performance comparison data
        methods = ['Method A', 'Method B', 'Method C', 'Method D']
        accuracy = [0.85, 0.88, 0.92, 0.95]
        std_dev = [0.02, 0.015, 0.018, 0.012]
        
        # Plot bar chart with error bars
        bars = ax.bar(methods, accuracy, 
                     yerr=std_dev, 
                     color='#0066CC', 
                     alpha=0.8,
                     capsize=3,
                     error_kw={'linewidth': 1.0, 'capthick': 1.0})
        
        # Add value labels
        for bar, acc, std in zip(bars, accuracy, std_dev):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + std + 0.01,
                   f'{acc:.2f}',
                   ha='center', va='bottom', fontsize=7)
        
        ax.set_xlabel('Method', fontweight='normal')
        ax.set_ylabel('Accuracy', fontweight='normal')
        ax.set_title('Performance Comparison of Different Methods', fontweight='bold')
        ax.set_ylim(0.8, 1.0)
        ax.grid(True, axis='y', alpha=0.3, linestyle=':')
        
        # Add significance marker
        ax.text(0.5, 0.98, '* p < 0.05', 
               transform=ax.transAxes, 
               fontsize=7, 
               verticalalignment='top')
        
        # Save
        output_dir = "output/example3_en"
        os.makedirs(output_dir, exist_ok=True)
        
        paths = save_multiformat(
            fig,
            f"{output_dir}/ieee_performance",
            formats=['png', 'svg', 'pdf', 'eps'],
            dpi=300
        )
        
        print(f"\nSaved files:")
        for path in paths:
            print(f"  - {path}")
        
        plt.close(fig)
    
    print("\nExample 3 completed!\n")


# ====================
# Example 4: Configuration Management
# ====================
def example_4_config_management():
    """
    Example 4: Configuration Management Demo
    
    Demonstrates YAML/JSON configuration loading, context management, etc.
    Corresponds to Sections 2.3.1 and 4.1 of the paper.
    """
    print("\n" + "=" * 70)
    print("Example 4: Configuration Management Demo")
    print("=" * 70)
    
    # 1. List supported journals
    print("\n1. Supported Journals:")
    journals = list_supported_journals()
    for journal in journals:
        info = get_journal_info(journal)
        print(f"   - {journal}: {info['name']}")
        print(f"     {info['description']}")
    
    # 2. Get journal configuration
    print("\n2. CEA Journal Configuration:")
    config = get_journal_config('cea')
    print(f"   Font: {config['font']['family']}")
    print(f"   Font sizes: Title {config['font']['titlesize']}pt, "
          f"Label {config['font']['labelsize']}pt")
    print(f"   Single column size: {config['figure_size']['single']} inches")
    print(f"   Recommended formats: {', '.join(config['output']['formats'])}")
    
    # 3. Use ConfigManager to load and save configurations
    print("\n3. ConfigManager Demo:")
    manager = ConfigManager()
    
    # Save configuration to JSON
    output_dir = "output/example4_en"
    os.makedirs(output_dir, exist_ok=True)
    
    config_path = f"{output_dir}/custom_config.json"
    custom_config = {
        'font': {
            'family': ['Arial', 'sans-serif'],
            'titlesize': 12,
            'labelsize': 10,
            'ticksize': 9
        },
        'figure_size': {
            'single': (4.0, 3.0),
            'double': (8.0, 3.0)
        },
        'output': {
            'dpi': 300,
            'formats': ['pdf', 'png']
        }
    }
    
    manager.save_config(custom_config, config_path, format='json')
    print(f"   Configuration saved to: {config_path}")
    
    # Load configuration
    loaded_config = manager.load_config(config_path)
    print(f"   Configuration loaded: {loaded_config['font']['family']}")
    
    # 4. Use PlotConfigContext
    print("\n4. Context Manager Demo:")
    
    with PlotConfigContext(custom_config):
        fig, ax = plt.subplots(figsize=(4.0, 3.0), dpi=300)
        
        x = np.linspace(0, 10, 100)
        ax.plot(x, np.sin(x), label='sin(x)')
        ax.set_xlabel('X Axis')
        ax.set_ylabel('Y Axis')
        ax.set_title('Custom Configuration Demo')
        ax.legend()
        
        save_path = f"{output_dir}/custom_config_demo"
        paths = save_multiformat(fig, save_path, formats=['png', 'svg', 'pdf', 'eps'], dpi=300)
        
        print(f"   Figure saved: {paths[0]}")
        plt.close(fig)
    
    print("\nExample 4 completed!\n")


# ====================
# Example 5: Compliance Check
# ====================
def example_5_compliance_check():
    """
    Example 5: Compliance Check Demo
    
    Shows how to check if a figure meets journal specifications.
    Corresponds to Section 4.3 of the paper.
    """
    print("\n" + "=" * 70)
    print("Example 5: Compliance Check Demo")
    print("=" * 70)
    
    # Create a compliant figure
    print("\n1. Creating compliant figure:")
    with setup_journal_style('cea'):
        fig, ax = plt.subplots(figsize=(3.15, 2.36), dpi=300)
        
        x = np.linspace(0, 10, 100)
        ax.plot(x, np.sin(x))
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Amplitude')
        ax.set_title('Sine Function')
        
        # Compliance check
        report = check_compliance(fig, CEA_CONFIG, strict=False)
        print(f"   Result: {'Passed' if report.passed else 'Failed'}")
        print(f"   Checks: {len(report.checks)}")
        if report.warnings:
            print(f"   Warnings: {len(report.warnings)}")
        
        plt.close(fig)
    
    # Create a non-compliant figure (low DPI intentionally)
    print("\n2. Creating non-compliant figure (low DPI):")
    fig, ax = plt.subplots(figsize=(3.15, 2.36), dpi=72)  # Low DPI
    
    x = np.linspace(0, 10, 100)
    ax.plot(x, np.sin(x))
    ax.set_xlabel('Time (s)')
    ax.set_ylabel('Amplitude')
    
    # Strict mode check
    report = check_compliance(fig, CEA_CONFIG, strict=True)
    print(f"   Result: {'Passed' if report.passed else 'Failed'}")
    if not report.passed:
        print(f"   Errors: {report.errors}")
    
    plt.close(fig)
    
    print("\nExample 5 completed!\n")


# ====================
# Example 6: Dynamic Layout
# ====================
def example_6_dynamic_layout():
    """
    Example 6: Dynamic Layout Calculation
    
    Demonstrates automatic optimal subplot layout calculation.
    Corresponds to Section 2.3.2 of the paper.
    """
    print("\n" + "=" * 70)
    print("Example 6: Dynamic Layout Calculation")
    print("=" * 70)
    
    # Test different numbers of subplots
    for n_plots in [3, 5, 7]:
        rows, cols = calculate_optimal_layout(n_plots)
        print(f"\n{n_plots} plots -> {rows} rows x {cols} columns")
        
        # Create dynamic grid
        fig, axes = create_dynamic_grid(
            n_plots, 
            figsize=(6, 4),
            dpi=300,
            add_labels=True
        )
        
        # Plot simple graphics in each subplot
        for i, ax in enumerate(axes.flat[:n_plots]):
            x = np.linspace(0, 10, 50)
            ax.plot(x, np.sin(x + i))
            ax.set_title(f'Subplot {i+1}')
        
        # Save
        output_dir = "output/example6_en"
        os.makedirs(output_dir, exist_ok=True)
        
        save_path = f"{output_dir}/layout_{n_plots}plots"
        paths = save_multiformat(fig, save_path, formats=['png', 'svg', 'pdf', 'eps'], dpi=300)
        
        print(f"   Saved: {paths[0]}")
        plt.close(fig)
    
    print("\nExample 6 completed!\n")


# ====================
# Main Function
# ====================
def main():
    """Main function: run all examples"""
    print("\n")
    print("*" * 70)
    print("Paper: Python Chart Toolchain for Academic Publishing")
    print("Complete Example Code (English Version)")
    print("*" * 70)
    print("\n")
    
    # Create output directory
    os.makedirs("output", exist_ok=True)
    
    # Run all examples
    try:
        example_1_basic_api()          # Example 1: API usage
        example_2_multi_subplot()      # Example 2: Multi-panel figure
        example_3_ieee_performance()   # Example 3: IEEE performance comparison
        example_4_config_management()  # Example 4: Configuration management
        example_5_compliance_check()   # Example 5: Compliance check
        example_6_dynamic_layout()     # Example 6: Dynamic layout
        
        print("*" * 70)
        print("All examples completed!")
        print("Output files saved in output/ directory")
        print("*" * 70)
        
    except Exception as e:
        print(f"\nError running examples: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
