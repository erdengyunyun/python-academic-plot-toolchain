"""
图表标注工具模块

提供图表标注、文本添加和注释功能。
"""

import matplotlib.pyplot as plt
from typing import Optional, Dict, Any


class AnnotationUtils:
    """
    图表标注工具类
    
    提供图表标注、文本添加和注释功能。
    """
    
    @staticmethod
    def add_text(ax: plt.Axes, x: float, y: float, text: str, 
                fontsize: int = 12,
                fontweight: str = 'normal',
                color: str = 'black',
                ha: str = 'center',
                va: str = 'center',
                **kwargs) -> None:
        """
        在图表中添加文本
        
        Args:
            ax: 坐标轴对象
            x: x坐标
            y: y坐标
            text: 文本内容
            fontsize: 字体大小，默认12
            fontweight: 字体粗细，默认'normal'
            color: 文本颜色，默认'black'
            ha: 水平对齐方式，默认'center'
            va: 垂直对齐方式，默认'center'
            **kwargs: 传递给ax.text的其他参数
        """
        ax.text(x, y, text, fontsize=fontsize, fontweight=fontweight,
               color=color, ha=ha, va=va, **kwargs)
    
    @staticmethod
    def add_annotation(ax: plt.Axes, x: float, y: float, 
                      text: str, xytext: tuple,
                      arrowprops: Optional[Dict[str, Any]] = None,
                      fontsize: int = 12,
                      fontweight: str = 'normal',
                      color: str = 'black',
                      **kwargs) -> None:
        """
        在图表中添加带箭头的注释
        
        Args:
            ax: 坐标轴对象
            x: 标注点x坐标
            y: 标注点y坐标
            text: 注释文本
            xytext: 文本位置
            arrowprops: 箭头属性，默认None
            fontsize: 字体大小，默认12
            fontweight: 字体粗细，默认'normal'
            color: 文本颜色，默认'black'
            **kwargs: 传递给ax.annotate的其他参数
        """
        if arrowprops is None:
            arrowprops = {
                'arrowstyle': '->',
                'linewidth': 1.0,
                'color': 'black'
            }
        
        ax.annotate(text, xy=(x, y), xytext=xytext, arrowprops=arrowprops,
                   fontsize=fontsize, fontweight=fontweight, color=color,
                   **kwargs)
    
    @staticmethod
    def add_vertical_line(ax: plt.Axes, x: float, 
                         color: str = 'red',
                         linestyle: str = '--',
                         linewidth: float = 1.0,
                         alpha: float = 0.8,
                         label: Optional[str] = None,
                         **kwargs) -> None:
        """
        添加垂直参考线
        
        Args:
            ax: 坐标轴对象
            x: x坐标
            color: 线条颜色，默认'red'
            linestyle: 线型，默认'--'
            linewidth: 线宽，默认1.0
            alpha: 透明度，默认0.8
            label: 标签，默认None
            **kwargs: 传递给ax.axvline的其他参数
        """
        ax.axvline(x=x, color=color, linestyle=linestyle,
                  linewidth=linewidth, alpha=alpha, label=label,
                  **kwargs)
    
    @staticmethod
    def add_horizontal_line(ax: plt.Axes, y: float, 
                           color: str = 'red',
                           linestyle: str = '--',
                           linewidth: float = 1.0,
                           alpha: float = 0.8,
                           label: Optional[str] = None,
                           **kwargs) -> None:
        """
        添加水平参考线
        
        Args:
            ax: 坐标轴对象
            y: y坐标
            color: 线条颜色，默认'red'
            linestyle: 线型，默认'--'
            linewidth: 线宽，默认1.0
            alpha: 透明度，默认0.8
            label: 标签，默认None
            **kwargs: 传递给ax.axhline的其他参数
        """
        ax.axhline(y=y, color=color, linestyle=linestyle,
                  linewidth=linewidth, alpha=alpha, label=label,
                  **kwargs)
    
    @staticmethod
    def add_rectangle(ax: plt.Axes, xmin: float, xmax: float,
                     ymin: float, ymax: float,
                     color: str = 'blue',
                     alpha: float = 0.2,
                     linestyle: str = '-',
                     linewidth: float = 1.0,
                     label: Optional[str] = None,
                     **kwargs) -> None:
        """
        添加矩形区域
        
        Args:
            ax: 坐标轴对象
            xmin: 左上角x坐标
            xmax: 右下角x坐标
            ymin: 左上角y坐标
            ymax: 右下角y坐标
            color: 填充颜色，默认'blue'
            alpha: 透明度，默认0.2
            linestyle: 边框线型，默认'-'
            linewidth: 边框线宽，默认1.0
            label: 标签，默认None
            **kwargs: 传递给Rectangle的其他参数
        """
        from matplotlib.patches import Rectangle
        
        # 创建矩形对象
        rect = Rectangle((xmin, ymin), xmax - xmin, ymax - ymin,
                       color=color, alpha=alpha, linestyle=linestyle,
                       linewidth=linewidth, label=label, fill=True, **kwargs)
        
        # 添加到坐标轴
        ax.add_patch(rect)
    
    @staticmethod
    def add_legend(ax: plt.Axes, 
                  loc: str = 'best',
                  fontsize: int = 12,
                  frameon: bool = True,
                  **kwargs) -> None:
        """
        添加图例
        
        Args:
            ax: 坐标轴对象
            loc: 图例位置，默认'best'
            fontsize: 字体大小，默认12
            frameon: 是否显示边框，默认True
            **kwargs: 传递给ax.legend的其他参数
        """
        ax.legend(loc=loc, fontsize=fontsize, frameon=frameon, **kwargs)
    
    @staticmethod
    def add_title(ax: plt.Axes, title: str,
                 fontsize: int = 16,
                 fontweight: str = 'bold',
                 color: str = 'black',
                 pad: float = 10.0,
                 **kwargs) -> None:
        """
        添加图表标题
        
        Args:
            ax: 坐标轴对象
            title: 标题文本
            fontsize: 字体大小，默认16
            fontweight: 字体粗细，默认'bold'
            color: 文本颜色，默认'black'
            pad: 标题与图表的间距，默认10.0
            **kwargs: 传递给ax.set_title的其他参数
        """
        ax.set_title(title, fontsize=fontsize, fontweight=fontweight,
                   color=color, pad=pad, **kwargs)
    
    @staticmethod
    def add_labels(ax: plt.Axes, xlabel: str, ylabel: str,
                  fontsize: int = 14,
                  fontweight: str = 'normal',
                  color: str = 'black',
                  **kwargs) -> None:
        """
        添加坐标轴标签
        
        Args:
            ax: 坐标轴对象
            xlabel: x轴标签
            ylabel: y轴标签
            fontsize: 字体大小，默认14
            fontweight: 字体粗细，默认'normal'
            color: 文本颜色，默认'black'
            **kwargs: 传递给ax.set_xlabel和ax.set_ylabel的其他参数
        """
        ax.set_xlabel(xlabel, fontsize=fontsize, fontweight=fontweight,
                     color=color, **kwargs)
        ax.set_ylabel(ylabel, fontsize=fontsize, fontweight=fontweight,
                     color=color, **kwargs)
    
    @staticmethod
    def add_statistics(ax: plt.Axes, stats: Dict[str, float],
                      x: float = 0.05,
                      y: float = 0.95,
                      fontsize: int = 12,
                      **kwargs) -> None:
        """
        添加统计信息
        
        Args:
            ax: 坐标轴对象
            stats: 统计信息字典
            x: 文本x位置（轴坐标系），默认0.05
            y: 文本y位置（轴坐标系），默认0.95
            fontsize: 字体大小，默认12
            **kwargs: 传递给ax.text的其他参数
        """
        # 构建统计信息文本
        stat_text = "\n".join([f"{key}: {value:.2f}" for key, value in stats.items()])
        
        # 添加文本
        ax.text(x, y, stat_text, fontsize=fontsize,
               transform=ax.transAxes, verticalalignment='top',
               bbox=dict(boxstyle='round', facecolor='white', alpha=0.8),
               **kwargs)
    
    @staticmethod
    def add_textbook_annotation(ax: plt.Axes, x: float, y: float, 
                               text: str, 
                               fontsize: int = 12, 
                               fontweight: str = 'normal',
                               box_color: str = 'white',
                               box_alpha: float = 0.9,
                               arrow_color: str = 'black',
                               arrow_width: float = 1.5,
                               **kwargs) -> None:
        """
        添加教材专用注释
        
        Args:
            ax: 坐标轴对象
            x: 标注点x坐标
            y: 标注点y坐标
            text: 注释文本
            fontsize: 字体大小
            fontweight: 字体粗细
            box_color: 注释框颜色
            box_alpha: 注释框透明度
            arrow_color: 箭头颜色
            arrow_width: 箭头宽度
            **kwargs: 其他参数
        """
        arrowprops = {
            'arrowstyle': '->',
            'linewidth': arrow_width,
            'color': arrow_color
        }
        
        ax.annotate(text, xy=(x, y), 
                   xytext=(10, -10), 
                   textcoords='offset points',
                   fontsize=fontsize, 
                   fontweight=fontweight,
                   arrowprops=arrowprops,
                   bbox=dict(boxstyle='round', 
                            facecolor=box_color, 
                            alpha=box_alpha,
                            edgecolor='black',
                            linewidth=1.0),
                   **kwargs)
    
    @staticmethod
    def add_subplot_label(ax: plt.Axes, label: str,
                         x: float = 0.5,
                         y: float = -0.7,
                         fontsize: int = 12,
                         fontweight: str = 'bold',
                         fontfamily: str = 'Times New Roman',
                         **kwargs) -> None:
        """
        为子图添加序号标签（如(a), (b), (c)等）
        
        Args:
            ax: 坐标轴对象
            label: 标签文本（如'(a)'）
            x: 文本x位置（轴坐标系），默认0.5（底部居中）
            y: 文本y位置（轴坐标系），默认-0.7（子图下方独立一行，与横轴标签有足够距离）
            fontsize: 字体大小，默认12，与其他文本协调
            fontweight: 字体粗细，默认'bold'
            fontfamily: 字体，默认'Times New Roman'
            **kwargs: 传递给ax.text或ax.text2D的其他参数
        """
        # 根据轴类型选择合适的文本添加方法
        if hasattr(ax, 'text2D'):  # 3D轴对象
            ax.text2D(x, y, label, transform=ax.transAxes,
                     fontsize=fontsize, fontweight=fontweight,
                     fontfamily=fontfamily, ha='center', **kwargs)
        else:  # 2D轴对象
            ax.text(x, y, label, transform=ax.transAxes,
                   fontsize=fontsize, fontweight=fontweight,
                   fontfamily=fontfamily, ha='center', **kwargs)


# 提供便捷函数
def add_text(ax: plt.Axes, x: float, y: float, text: str, 
             fontsize: int = 12,
             fontweight: str = 'normal',
             color: str = 'black',
             ha: str = 'center',
             va: str = 'center',
             **kwargs) -> None:
    """
    在图表中添加文本
    
    Args:
        ax: 坐标轴对象
        x: x坐标
        y: y坐标
        text: 文本内容
        fontsize: 字体大小，默认12
        fontweight: 字体粗细，默认'normal'
        color: 文本颜色，默认'black'
        ha: 水平对齐方式，默认'center'
        va: 垂直对齐方式，默认'center'
        **kwargs: 传递给ax.text的其他参数
    """
    AnnotationUtils.add_text(ax, x, y, text, fontsize, fontweight,
                           color, ha, va, **kwargs)


def add_annotation(ax: plt.Axes, x: float, y: float, 
                   text: str, xytext: tuple,
                   arrowprops: Optional[Dict[str, Any]] = None,
                   fontsize: int = 12,
                   fontweight: str = 'normal',
                   color: str = 'black',
                   **kwargs) -> None:
    """
    在图表中添加带箭头的注释
    
    Args:
        ax: 坐标轴对象
        x: 标注点x坐标
        y: 标注点y坐标
        text: 注释文本
        xytext: 文本位置
        arrowprops: 箭头属性，默认None
        fontsize: 字体大小，默认12
        fontweight: 字体粗细，默认'normal'
        color: 文本颜色，默认'black'
        **kwargs: 传递给ax.annotate的其他参数
    """
    AnnotationUtils.add_annotation(ax, x, y, text, xytext, arrowprops,
                                  fontsize, fontweight, color, **kwargs)


def add_vertical_line(ax: plt.Axes, x: float, 
                      color: str = 'red',
                      linestyle: str = '--',
                      linewidth: float = 1.0,
                      alpha: float = 0.8,
                      label: Optional[str] = None,
                      **kwargs) -> None:
    """
    添加垂直参考线
    
    Args:
        ax: 坐标轴对象
        x: x坐标
        color: 线条颜色，默认'red'
        linestyle: 线型，默认'--'
        linewidth: 线宽，默认1.0
        alpha: 透明度，默认0.8
        label: 标签，默认None
        **kwargs: 传递给ax.axvline的其他参数
    """
    AnnotationUtils.add_vertical_line(ax, x, color, linestyle, linewidth,
                                     alpha, label, **kwargs)


def add_horizontal_line(ax: plt.Axes, y: float, 
                        color: str = 'red',
                        linestyle: str = '--',
                        linewidth: float = 1.0,
                        alpha: float = 0.8,
                        label: Optional[str] = None,
                        **kwargs) -> None:
    """
    添加水平参考线
    
    Args:
        ax: 坐标轴对象
        y: y坐标
        color: 线条颜色，默认'red'
        linestyle: 线型，默认'--'
        linewidth: 线宽，默认1.0
        alpha: 透明度，默认0.8
        label: 标签，默认None
        **kwargs: 传递给ax.axhline的其他参数
    """
    AnnotationUtils.add_horizontal_line(ax, y, color, linestyle, linewidth,
                                       alpha, label, **kwargs)


def add_statistics(ax: plt.Axes, stats: Dict[str, float],
                   x: float = 0.05,
                   y: float = 0.95,
                   fontsize: int = 12,
                   **kwargs) -> None:
    """
    添加统计信息
    
    Args:
        ax: 坐标轴对象
        stats: 统计信息字典
        x: 文本x位置（轴坐标系），默认0.05
        y: 文本y位置（轴坐标系），默认0.95
        fontsize: 字体大小，默认12
        **kwargs: 传递给ax.text的其他参数
    """
    AnnotationUtils.add_statistics(ax, stats, x, y, fontsize, **kwargs)


def add_textbook_annotation(ax: plt.Axes, x: float, y: float, 
                           text: str, 
                           fontsize: int = 12, 
                           fontweight: str = 'normal',
                           box_color: str = 'white',
                           box_alpha: float = 0.9,
                           arrow_color: str = 'black',
                           arrow_width: float = 1.5,
                           **kwargs) -> None:
    """
    添加教材专用注释
    
    Args:
        ax: 坐标轴对象
        x: 标注点x坐标
        y: 标注点y坐标
        text: 注释文本
        fontsize: 字体大小
        fontweight: 字体粗细
        box_color: 注释框颜色
        box_alpha: 注释框透明度
        arrow_color: 箭头颜色
        arrow_width: 箭头宽度
        **kwargs: 其他参数
    """
    AnnotationUtils.add_textbook_annotation(ax, x, y, text, 
                                           fontsize, fontweight,
                                           box_color, box_alpha,
                                           arrow_color, arrow_width,
                                           **kwargs)


def add_subplot_label(ax: plt.Axes, label: str,
                      x: float = 0.5,
                      y: float = -0.15,
                      fontsize: int = 14,
                      fontweight: str = 'bold',
                      fontfamily: str = 'Times New Roman',
                      **kwargs) -> None:
    """
    为子图添加序号标签（如(a), (b), (c)等）
    
    Args:
        ax: 坐标轴对象
        label: 标签文本（如'(a)'）
        x: 文本x位置（轴坐标系），默认0.5（居中）
        y: 文本y位置（轴坐标系），默认-0.15（子图下方）
        fontsize: 字体大小，默认14
        fontweight: 字体粗细，默认'bold'
        fontfamily: 字体，默认'Times New Roman'
        **kwargs: 传递给ax.text或ax.text2D的其他参数
    """
    AnnotationUtils.add_subplot_label(ax, label, x, y, fontsize, fontweight, fontfamily, **kwargs)