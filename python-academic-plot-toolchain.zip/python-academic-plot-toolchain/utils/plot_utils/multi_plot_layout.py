"""
多图布局工具模块

提供多图表布局计算和管理功能。
"""

import math
import numpy as np
import matplotlib.pyplot as plt
from typing import List, Tuple, Optional, Callable


class MultiPlotLayout:
    """
    多图布局管理类
    
    提供多图表布局计算和管理功能，支持动态布局计算。
    """
    
    @staticmethod
    def calculate_optimal_layout(total_plots: int, max_cols: Optional[int] = None) -> Tuple[int, int]:
        """
        根据图表数量计算最优的子图布局
        
        Args:
            total_plots: 图表总数
            max_cols: 最大列数，默认None
            
        Returns:
            Tuple[int, int]: (行数, 列数)
        """
        if total_plots <= 0:
            return 1, 1
        
        # 计算最佳列数
        if max_cols is None:
            cols = math.ceil(math.sqrt(total_plots))
        else:
            cols = min(max_cols, math.ceil(math.sqrt(total_plots)))
        
        rows = math.ceil(total_plots / cols)
        
        # 调整为更接近方形的布局
        while cols > 1 and rows * (cols - 1) >= total_plots:
            cols -= 1
            rows = math.ceil(total_plots / cols)
        
        return rows, cols
    
    @staticmethod
    def get_subplot_position(index: int, rows: int, cols: int) -> int:
        """
        获取子图的位置索引
        
        Args:
            index: 子图索引（从0开始）
            rows: 行数
            cols: 列数
            
        Returns:
            int: 子图位置（从1开始）
        """
        return index + 1
    
    @staticmethod
    def create_grid(rows: int, cols: int, 
                   figsize: Optional[tuple] = None, 
                   dpi: int = 300,
                   add_labels: bool = True,
                   hspace: float = 0.5,
                   wspace: float = 0.4) -> Tuple[plt.Figure, np.ndarray]:
        """
        创建子图网格
        
        Args:
            rows: 行数
            cols: 列数
            figsize: 图表尺寸，默认None
            dpi: 图表分辨率，默认300
            add_labels: 是否自动添加子图标签，默认True
            hspace: 垂直间距，默认0.5，确保多行图片之间有足够空间
            wspace: 水平间距，默认0.4，确保横向子图之间有足够空间
            
        Returns:
            Tuple[plt.Figure, np.ndarray]: 图表对象和坐标轴数组
        """
        # 创建子图，设置默认的垂直和水平间距
        fig, axes = plt.subplots(rows, cols, figsize=figsize, dpi=dpi, 
                                gridspec_kw={'hspace': hspace, 'wspace': wspace})  # 增大垂直和水平间距
        
        # 确保axes是数组
        if rows == 1 and cols == 1:
            axes = np.array([axes])
        elif rows == 1:
            axes = np.array(axes)
        elif cols == 1:
            axes = np.array(axes)
        
        # 自动添加子图标签
        if add_labels:
            MultiPlotLayout.add_subplot_labels(axes)
        
        return fig, axes
    
    @staticmethod
    def add_subplot_labels(axes: np.ndarray, start_index: int = 0) -> None:
        """
        为子图添加序号标签（如'(a)', '(b)', '(c)'等）
        
        Args:
            axes: 坐标轴数组（2D或1D）
            start_index: 起始索引，默认0
        """
        from .annotation_utils import add_subplot_label
        
        axes_flat = axes.flatten()
        for i, ax in enumerate(axes_flat, start=start_index):
            if ax.get_visible():
                # 生成标签，如'(a)', '(b)', '(c)'等
                label = f'({chr(ord("a") + i)})'
                add_subplot_label(ax, label)
    
    @staticmethod
    def create_dynamic_grid(total_plots: int, 
                           max_cols: Optional[int] = None,
                           figsize: Optional[tuple] = None,
                           dpi: int = 300,
                           add_labels: bool = True) -> Tuple[plt.Figure, np.ndarray]:
        """
        根据图表数量动态创建子图网格
        
        Args:
            total_plots: 图表总数
            max_cols: 最大列数，默认None
            figsize: 图表尺寸，默认None
            dpi: 图表分辨率，默认300
            add_labels: 是否自动添加子图标签，默认True
            
        Returns:
            Tuple[plt.Figure, np.ndarray]: 图表对象和坐标轴数组
        """
        # 计算最优布局
        rows, cols = MultiPlotLayout.calculate_optimal_layout(total_plots, max_cols)
        
        # 创建子图网格，设置默认的垂直和水平间距
        fig, axes = plt.subplots(rows, cols, figsize=figsize, dpi=dpi, 
                                gridspec_kw={'hspace': 0.5, 'wspace': 0.4})  # 增大垂直和水平间距
        
        # 确保axes是数组
        if rows == 1 and cols == 1:
            axes = np.array([axes])
        elif rows == 1:
            axes = np.array(axes)
        elif cols == 1:
            axes = np.array(axes)
        
        # 隐藏多余的子图
        if total_plots < rows * cols:
            for i in range(total_plots, rows * cols):
                ax = axes.flatten()[i]
                ax.axis('off')
        
        # 自动添加子图标签
        if add_labels:
            MultiPlotLayout.add_subplot_labels(axes)
        
        return fig, axes
    
    @staticmethod
    def adjust_spacing(fig: plt.Figure, 
                      wspace: Optional[float] = None,
                      hspace: Optional[float] = None,
                      left: Optional[float] = None,
                      right: Optional[float] = None,
                      top: Optional[float] = None,
                      bottom: Optional[float] = None) -> None:
        """
        调整子图间距
        
        Args:
            fig: 图表对象
            wspace: 水平间距
            hspace: 垂直间距
            left: 左边界
            right: 右边界
            top: 上边界
            bottom: 下边界
        """
        fig.subplots_adjust(wspace=wspace, hspace=hspace, 
                          left=left, right=right, 
                          top=top, bottom=bottom)
    
    @staticmethod
    def create_combined_figure(plots: List[Tuple[Callable, str]],
                              rows: Optional[int] = None,
                              cols: Optional[int] = None,
                              figsize: Optional[tuple] = None,
                              dpi: int = 300,
                              title: Optional[str] = None,
                              add_labels: bool = True,
                              hspace: float = 0.5,
                              wspace: float = 0.4) -> plt.Figure:
        """
        创建组合图
        
        Args:
            plots: 图表列表，每个元素是(ax_func, title)元组
            rows: 行数，默认None，自动计算
            cols: 列数，默认None，自动计算
            figsize: 图表尺寸，默认None
            dpi: 图表分辨率，默认300
            title: 图表标题，默认None
            add_labels: 是否自动添加子图标签，默认True
            hspace: 垂直间距，默认0.5，确保多行图片之间有足够空间
            wspace: 水平间距，默认0.4，确保横向子图之间有足够空间
            
        Returns:
            plt.Figure: 组合图表对象
        """
        total_plots = len(plots)
        
        # 计算布局
        if rows is None or cols is None:
            rows, cols = MultiPlotLayout.calculate_optimal_layout(total_plots)
        
        # 创建子图网格
        fig, axes = MultiPlotLayout.create_grid(rows, cols, figsize, dpi, 
                                               add_labels=add_labels, hspace=hspace, wspace=wspace)
        axes_flat = axes.flatten()
        
        # 绘制每个图表
        for i, (plot_func, plot_title) in enumerate(plots):
            ax = axes_flat[i]
            plot_func(ax)
            if plot_title:
                ax.set_title(plot_title)
        
        # 隐藏多余的子图
        for i in range(total_plots, len(axes_flat)):
            axes_flat[i].axis('off')
        
        # 添加总标题
        if title:
            fig.suptitle(title, fontsize=18, fontweight='bold')
        
        # 调整布局，为标签留出空间
        plt.tight_layout(rect=(0, 0.05, 1, 1))
        return fig


# 提供便捷函数
def calculate_optimal_layout(total_plots: int, max_cols: Optional[int] = None) -> Tuple[int, int]:
    """
    根据图表数量计算最优的子图布局
    
    Args:
        total_plots: 图表总数
        max_cols: 最大列数，默认None
        
    Returns:
        Tuple[int, int]: (行数, 列数)
    """
    return MultiPlotLayout.calculate_optimal_layout(total_plots, max_cols)


def create_dynamic_grid(total_plots: int, 
                       max_cols: Optional[int] = None,
                       figsize: Optional[tuple] = None,
                       dpi: int = 300,
                       add_labels: bool = True) -> Tuple[plt.Figure, np.ndarray]:
    """
    根据图表数量动态创建子图网格
    
    Args:
        total_plots: 图表总数
        max_cols: 最大列数，默认None
        figsize: 图表尺寸，默认None
        dpi: 图表分辨率，默认300
        add_labels: 是否自动添加子图标签，默认True
        
    Returns:
        Tuple[plt.Figure, np.ndarray]: 图表对象和坐标轴数组
    """
    return MultiPlotLayout.create_dynamic_grid(total_plots, max_cols, figsize, dpi, add_labels)